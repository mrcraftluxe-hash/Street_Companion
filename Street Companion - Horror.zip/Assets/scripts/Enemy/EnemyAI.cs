using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class EnemyAI : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private Transform player;
    [SerializeField] private Transform enemyEye; // Точка, откуда враг "смотрит"
    [SerializeField] private Animator animator;
    [SerializeField] private CharacterController controller;
    [SerializeField] private NavMeshAgent navAgent; // Для навигации
    
    [Header("Detection Settings")]
    [SerializeField] private float detectionRange = 20f;
    [SerializeField] private float fieldOfView = 90f; // Угол обзора
    [SerializeField] private float eyeHeight = 1.8f; // Высота глаз врага
    [SerializeField] private LayerMask obstacleMask; // Что блокирует обзор
    [SerializeField] private LayerMask playerMask; // Слой игрока
    
    [Header("Hearing Settings")]
    [SerializeField] private float hearingRange = 15f;
    [SerializeField] private float alertOnSoundRange = 10f; // Расстояние, на котором враг слышит звуки
    [SerializeField] private float investigationTime = 10f; // Сколько ищет после звука
    
    [Header("Light Sensitivity")]
    [SerializeField] private float lightDetectionRange = 5f;
    [SerializeField] private float lightDetectionAngle = 60f;
    [SerializeField] private float lightSensitivity = 1f; // Как сильно реагирует на свет
    [SerializeField] private LayerMask lightMask;
    
    [Header("Movement Settings")]
    [SerializeField] private float walkSpeed = 2f;
    [SerializeField] private float runSpeed = 4f;
    [SerializeField] private float patrolSpeed = 1.5f;
    [SerializeField] private float rotationSpeed = 5f;
    [SerializeField] private float acceleration = 8f;
    
    [Header("Patrol Settings")]
    [SerializeField] private Transform[] patrolPoints;
    [SerializeField] private float waitAtPatrolPoint = 2f;
    [SerializeField] private float patrolRadius = 10f; // Для случайного патруля
    [SerializeField] private bool randomPatrol = false;
    
    [Header("Combat/Chase Settings")]
    [SerializeField] private float chaseSpeed = 5f;
    [SerializeField] private float chaseDuration = 10f; // Сколько преследует, если потерял игрока
    [SerializeField] private float attackRange = 2f;
    [SerializeField] private float attackCooldown = 1.5f;
    [SerializeField] private int attackDamage = 20;
    [SerializeField] private float attackWindup = 0.5f; // Время перед атакой
    
    [Header("Search Settings")]
    [SerializeField] private float searchRadius = 15f;
    [SerializeField] private float searchTime = 5f;
    [SerializeField] private int searchPoints = 3; // Сколько точек проверяет при поиске
    
    [Header("Horror Effects")]
    [SerializeField] private float sanityDrainRange = 15f; // Радиус влияния на рассудок
    [SerializeField] private float sanityDrainRate = 5f; // Потеря рассудка в секунду
    [SerializeField] private AudioSource enemyAudio;
    [SerializeField] private AudioClip[] idleSounds;
    [SerializeField] private AudioClip[] chaseSounds;
    [SerializeField] private AudioClip[] attackSounds;
    [SerializeField] private AudioClip[] footstepSounds;
    [SerializeField] private float soundInterval = 5f;
    
    [Header("States Visual")]
    [SerializeField] private Light enemyLight; // Свет, меняющий цвет в зависимости от состояния
    [SerializeField] private Color patrolColor = Color.green;
    [SerializeField] private Color chaseColor = Color.red;
    [SerializeField] private Color searchColor = Color.yellow;
    [SerializeField] private Color idleColor = Color.blue;
    
    // States
    public enum EnemyState
    {
        Idle,
        Patrol,
        Chase,
        Search,
        Attack,
        Investigate, // Исследование звука
        Flee // Для слабых врагов
    }
    
    private EnemyState currentState = EnemyState.Idle;
    private EnemyState previousState;
    
    // Private variables
    private float stateTimer;
    private float soundTimer;
    private float attackTimer;
    private int currentPatrolIndex;
    private Vector3 lastKnownPlayerPosition;
    private Vector3 investigationPoint;
    private bool playerInSight;
    private float playerDistance;
    private float playerAngle;
    private Coroutine currentAction;
    private List<Vector3> searchPositions = new List<Vector3>();
    private int currentSearchIndex;
    private bool isAttacking;
    private bool playerIsHidden; // Для механик укрытия
    private float sanityDrainTimer;
    
    // Events for other systems
    public System.Action<EnemyState> OnStateChanged;
    public System.Action OnPlayerSpotted;
    public System.Action OnPlayerLost;
    public System.Action OnAttack;
    
    void Start()
    {
        // Get components
        if (player == null)
            player = GameObject.FindGameObjectWithTag("Player")?.transform;
            
        if (animator == null)
            animator = GetComponent<Animator>();
            
        if (controller == null)
            controller = GetComponent<CharacterController>();
            
        if (navAgent == null)
            navAgent = GetComponent<NavMeshAgent>();
            
        if (enemyEye == null)
            enemyEye = transform;
            
        // Initialize nav agent
        if (navAgent != null)
        {
            navAgent.speed = walkSpeed;
            navAgent.acceleration = acceleration;
        }
        
        // Start in patrol or idle
        if (patrolPoints.Length > 0)
            ChangeState(EnemyState.Patrol);
        else
            ChangeState(EnemyState.Idle);
            
        // Randomize sound timer
        soundTimer = Random.Range(1f, soundInterval);
    }
    
    void Update()
    {
        if (player == null) return;
        
        // Update detection
        UpdateDetection();
        
        // Update state
        UpdateState();
        
        // Update timers
        UpdateTimers();
        
        // Update visual effects
        UpdateVisualEffects();
        
        // Update sanity drain
        UpdateSanityDrain();
        
        // Update animation
        UpdateAnimation();
    }
    
    void UpdateDetection()
    {
        // Calculate distance to player
        playerDistance = Vector3.Distance(transform.position, player.position);
        
        // Calculate angle to player
        Vector3 directionToPlayer = (player.position - enemyEye.position).normalized;
        playerAngle = Vector3.Angle(enemyEye.forward, directionToPlayer);
        
        // Check if player is in sight
        playerInSight = false;
        
        if (playerDistance <= detectionRange && playerAngle <= fieldOfView * 0.5f)
        {
            // Raycast to check line of sight
            RaycastHit hit;
            if (Physics.Raycast(enemyEye.position, directionToPlayer, out hit, detectionRange, obstacleMask))
            {
                if (hit.transform.CompareTag("Player"))
                {
                    playerInSight = true;
                    lastKnownPlayerPosition = player.position;
                    
                    // Check if player is using light
                    CheckPlayerLight();
                }
            }
        }
        
        // Check hearing
        CheckHearing();
    }
    
    void CheckPlayerLight()
    {
        // Если игрок использует фонарик, враг видит его с большего расстояния
        PlayerFlashlight flashlight = player.GetComponent<PlayerFlashlight>();
        if (flashlight != null && flashlight.IsFlashlightOn())
        {
            // Увеличиваем дальность обнаружения
            float lightMultiplier = 1.5f;
            
            // Проверяем направление света
            Vector3 lightDirection = player.forward;
            Vector3 toEnemy = (transform.position - player.position).normalized;
            float lightAngle = Vector3.Angle(lightDirection, toEnemy);
            
            if (lightAngle <= lightDetectionAngle)
            {
                // Игрок светит прямо на врага - враг видит игрока
                playerInSight = true;
                lastKnownPlayerPosition = player.position;
            }
        }
    }
    
    void CheckHearing()
    {
        // Проверяем, есть ли звуки от игрока
        PlayerMovement movement = player.GetComponent<PlayerMovement>();
        if (movement != null && movement.IsMoving)
        {
            float soundRange = movement.IsRunning ? hearingRange : hearingRange * 0.5f;
            soundRange = movement.IsCrouching ? hearingRange * 0.2f : soundRange;
            
            if (playerDistance <= soundRange && currentState != EnemyState.Chase)
            {
                // Слышим игрока - идем на звук
                investigationPoint = player.position;
                ChangeState(EnemyState.Investigate);
            }
        }
    }
    
    void UpdateState()
    {
        switch (currentState)
        {
            case EnemyState.Idle:
                UpdateIdle();
                break;
            case EnemyState.Patrol:
                UpdatePatrol();
                break;
            case EnemyState.Chase:
                UpdateChase();
                break;
            case EnemyState.Search:
                UpdateSearch();
                break;
            case EnemyState.Attack:
                UpdateAttack();
                break;
            case EnemyState.Investigate:
                UpdateInvestigate();
                break;
        }
    }
    
    void UpdateIdle()
    {
        // Просто стоим, иногда оглядываемся
        stateTimer -= Time.deltaTime;
        
        if (stateTimer <= 0)
        {
            // Случайно поворачиваемся
            StartCoroutine(RotateRandom());
            stateTimer = Random.Range(3f, 7f);
        }
        
        // Если увидели игрока - начинаем преследование
        if (playerInSight)
        {
            ChangeState(EnemyState.Chase);
        }
    }
    
    void UpdatePatrol()
    {
        if (navAgent == null) return;
        
        // Если видим игрока - начинаем преследование
        if (playerInSight)
        {
            ChangeState(EnemyState.Chase);
            return;
        }
        
        // Патрулирование
        if (!navAgent.pathPending && navAgent.remainingDistance < 0.5f)
        {
            // Достигли точки патруля
            if (!randomPatrol)
            {
                // Переход к следующей точке
                currentPatrolIndex = (currentPatrolIndex + 1) % patrolPoints.Length;
                SetDestination(patrolPoints[currentPatrolIndex].position);
                
                // Ждем на точке
                StartCoroutine(WaitAtPatrolPoint());
            }
            else
            {
                // Случайная точка в радиусе
                Vector3 randomPoint = GetRandomPatrolPoint();
                SetDestination(randomPoint);
            }
        }
    }
    
    void UpdateChase()
    {
        if (navAgent == null) return;
        
        // Устанавливаем скорость преследования
        navAgent.speed = chaseSpeed;
        
        if (playerInSight)
        {
            // Видим игрока - преследуем
            lastKnownPlayerPosition = player.position;
            SetDestination(player.position);
            
            // Проверяем дистанцию для атаки
            if (playerDistance <= attackRange)
            {
                ChangeState(EnemyState.Attack);
            }
            
            // Сбрасываем таймер преследования
            stateTimer = chaseDuration;
        }
        else
        {
            // Потеряли игрока из виду
            stateTimer -= Time.deltaTime;
            
            // Продолжаем двигаться к последней известной позиции
            SetDestination(lastKnownPlayerPosition);
            
            if (stateTimer <= 0 || (navAgent.remainingDistance < 0.5f && !navAgent.pathPending))
            {
                // Время вышло или достигли последней позиции - начинаем поиск
                ChangeState(EnemyState.Search);
            }
        }
        
        // Звуки преследования
        if (chaseSounds.Length > 0 && enemyAudio != null)
        {
            soundTimer -= Time.deltaTime;
            if (soundTimer <= 0)
            {
                enemyAudio.PlayOneShot(chaseSounds[Random.Range(0, chaseSounds.Length)]);
                soundTimer = Random.Range(3f, 7f);
            }
        }
    }
    
    void UpdateSearch()
    {
        if (navAgent == null) return;
        
        navAgent.speed = walkSpeed;
        
        // Если увидели игрока во время поиска
        if (playerInSight)
        {
            ChangeState(EnemyState.Chase);
            return;
        }
        
        // Поиск по точкам
        if (searchPositions.Count == 0)
        {
            GenerateSearchPoints();
        }
        
        if (!navAgent.pathPending && navAgent.remainingDistance < 0.5f)
        {
            // Достигли точки поиска
            currentSearchIndex++;
            
            if (currentSearchIndex >= searchPositions.Count)
            {
                // Обыскали все точки - возвращаемся к патрулю
                ChangeState(EnemyState.Patrol);
            }
            else
            {
                // Идем к следующей точке
                SetDestination(searchPositions[currentSearchIndex]);
                
                // Ждем немного на точке
                StartCoroutine(WaitAtSearchPoint());
            }
        }
        
        // Таймер поиска
        stateTimer -= Time.deltaTime;
        if (stateTimer <= 0)
        {
            ChangeState(EnemyState.Patrol);
        }
    }
    
    void UpdateAttack()
    {
        if (player == null) return;
        
        // Смотрим на игрока
        LookAtPlayer();
        
        // Проверяем, все ли еще игрок в радиусе атаки
        if (playerDistance > attackRange)
        {
            ChangeState(EnemyState.Chase);
            return;
        }
        
        // Атака
        attackTimer -= Time.deltaTime;
        
        if (attackTimer <= 0 && !isAttacking)
        {
            StartCoroutine(PerformAttack());
        }
    }
    
    void UpdateInvestigate()
    {
        if (navAgent == null) return;
        
        navAgent.speed = walkSpeed;
        
        // Если увидели игрока - преследуем
        if (playerInSight)
        {
            ChangeState(EnemyState.Chase);
            return;
        }
        
        // Идем к точке исследования
        SetDestination(investigationPoint);
        
        if (!navAgent.pathPending && navAgent.remainingDistance < 0.5f)
        {
            // Достигли точки - ищем вокруг
            stateTimer -= Time.deltaTime;
            
            if (stateTimer <= 0)
            {
                // Если никого не нашли - возвращаемся
                ChangeState(previousState != EnemyState.Chase ? previousState : EnemyState.Patrol);
            }
        }
    }
    
    void GenerateSearchPoints()
    {
        searchPositions.Clear();
        
        for (int i = 0; i < searchPoints; i++)
        {
            // Генерируем точки вокруг последней позиции игрока
            Vector2 randomCircle = Random.insideUnitCircle * searchRadius;
            Vector3 searchPoint = lastKnownPlayerPosition + new Vector3(randomCircle.x, 0, randomCircle.y);
            
            // Проверяем, что точка на навмеше
            UnityEngine.AI.NavMeshHit hit;
            if (UnityEngine.AI.NavMesh.SamplePosition(searchPoint, out hit, searchRadius, UnityEngine.AI.NavMesh.AllAreas))
            {
                searchPositions.Add(hit.position);
            }
        }
        
        currentSearchIndex = 0;
        if (searchPositions.Count > 0)
        {
            SetDestination(searchPositions[0]);
        }
    }
    
    void SetDestination(Vector3 destination)
    {
        if (navAgent != null && navAgent.isOnNavMesh)
        {
            navAgent.SetDestination(destination);
        }
    }
    
    void LookAtPlayer()
    {
        Vector3 direction = (player.position - transform.position).normalized;
        direction.y = 0;
        Quaternion lookRotation = Quaternion.LookRotation(direction);
        transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, Time.deltaTime * rotationSpeed);
    }
    
    IEnumerator PerformAttack()
    {
        isAttacking = true;
        
        // Windup
        if (animator != null)
            animator.SetTrigger("AttackWindup");
            
        yield return new WaitForSeconds(attackWindup);
        
        // Check if player is still in range
        if (playerDistance <= attackRange)
        {
            // Apply damage
            PlayerSanity sanity = player.GetComponent<PlayerSanity>();
            if (sanity != null)
            {
                sanity.DrainSanity(attackDamage);
            }
            
            // Play attack sound
            if (attackSounds.Length > 0 && enemyAudio != null)
            {
                enemyAudio.PlayOneShot(attackSounds[Random.Range(0, attackSounds.Length)]);
            }
            
            // Trigger event
            OnAttack?.Invoke();
            
            // Attack animation
            if (animator != null)
                animator.SetTrigger("Attack");
        }
        
        attackTimer = attackCooldown;
        isAttacking = false;
    }
    
    IEnumerator RotateRandom()
    {
        float rotateTime = 1f;
        float timer = 0f;
        Quaternion startRot = transform.rotation;
        Quaternion targetRot = transform.rotation * Quaternion.Euler(0, Random.Range(-90f, 90f), 0);
        
        while (timer < rotateTime)
        {
            transform.rotation = Quaternion.Slerp(startRot, targetRot, timer / rotateTime);
            timer += Time.deltaTime;
            yield return null;
        }
    }
    
    IEnumerator WaitAtPatrolPoint()
    {
        if (navAgent != null)
            navAgent.isStopped = true;
            
        yield return new WaitForSeconds(waitAtPatrolPoint);
        
        if (navAgent != null)
            navAgent.isStopped = false;
    }
    
    IEnumerator WaitAtSearchPoint()
    {
        if (navAgent != null)
            navAgent.isStopped = true;
            
        yield return new WaitForSeconds(2f);
        
        if (navAgent != null)
            navAgent.isStopped = false;
    }
    
    Vector3 GetRandomPatrolPoint()
    {
        Vector2 randomCircle = Random.insideUnitCircle * patrolRadius;
        Vector3 randomPoint = transform.position + new Vector3(randomCircle.x, 0, randomCircle.y);
        
        UnityEngine.AI.NavMeshHit hit;
        if (UnityEngine.AI.NavMesh.SamplePosition(randomPoint, out hit, patrolRadius, UnityEngine.AI.NavMesh.AllAreas))
        {
            return hit.position;
        }
        
        return transform.position;
    }
    
    void UpdateTimers()
    {
        // Idle sounds
        if (idleSounds.Length > 0 && enemyAudio != null && currentState != EnemyState.Chase)
        {
            soundTimer -= Time.deltaTime;
            if (soundTimer <= 0)
            {
                enemyAudio.PlayOneShot(idleSounds[Random.Range(0, idleSounds.Length)], 0.5f);
                soundTimer = Random.Range(3f, soundInterval);
            }
        }
    }
    
    void UpdateVisualEffects()
    {
        if (enemyLight == null) return;
        
        // Меняем цвет света в зависимости от состояния
        switch (currentState)
        {
            case EnemyState.Patrol:
                enemyLight.color = patrolColor;
                break;
            case EnemyState.Chase:
                enemyLight.color = chaseColor;
                // Пульсация при преследовании
                float pulse = Mathf.Sin(Time.time * 5f) * 0.2f + 0.8f;
                enemyLight.intensity = pulse;
                break;
            case EnemyState.Search:
                enemyLight.color = searchColor;
                break;
            default:
                enemyLight.color = idleColor;
                break;
        }
    }
    
    void UpdateSanityDrain()
    {
        if (player == null) return;
        
        PlayerSanity sanity = player.GetComponent<PlayerSanity>();
        if (sanity == null) return;
        
        // Чем ближе враг, тем быстрее падает рассудок
        float distanceToPlayer = Vector3.Distance(transform.position, player.position);
        
        if (distanceToPlayer <= sanityDrainRange)
        {
            float drainMultiplier = 1f - (distanceToPlayer / sanityDrainRange);
            sanity.DrainSanity(sanityDrainRate * drainMultiplier * Time.deltaTime);
        }
    }
    
    void UpdateAnimation()
    {
        if (animator == null || navAgent == null) return;
        
        // Speed for blend tree
        float speed = navAgent.velocity.magnitude;
        animator.SetFloat("Speed", speed);
        
        // State for animation
        animator.SetInteger("State", (int)currentState);
        
        // Is chasing?
        animator.SetBool("IsChasing", currentState == EnemyState.Chase);
        
        // Is attacking?
        animator.SetBool("IsAttacking", currentState == EnemyState.Attack);
    }
    
    public void ChangeState(EnemyState newState)
    {
        if (newState == currentState) return;
        
        previousState = currentState;
        currentState = newState;
        
        // State enter actions
        switch (newState)
        {
            case EnemyState.Patrol:
                navAgent.speed = patrolSpeed;
                stateTimer = 0;
                break;
                
            case EnemyState.Chase:
                navAgent.speed = chaseSpeed;
                stateTimer = chaseDuration;
                OnPlayerSpotted?.Invoke();
                break;
                
            case EnemyState.Search:
                navAgent.speed = walkSpeed;
                stateTimer = searchTime;
                GenerateSearchPoints();
                OnPlayerLost?.Invoke();
                break;
                
            case EnemyState.Investigate:
                navAgent.speed = walkSpeed;
                stateTimer = investigationTime;
                break;
                
            case EnemyState.Attack:
                navAgent.isStopped = true;
                attackTimer = 0;
                break;
        }
        
        // Invoke event
        OnStateChanged?.Invoke(newState);
    }
    
    // Public methods for other scripts
    
    public void Alert(Vector3 position)
    {
        investigationPoint = position;
        ChangeState(EnemyState.Investigate);
    }
    
    public void SetPlayerHidden(bool hidden)
    {
        playerIsHidden = hidden;
    }
    
    public EnemyState GetCurrentState()
    {
        return currentState;
    }
    
    public float GetPlayerDistance()
    {
        return playerDistance;
    }
    
    public bool IsPlayerInSight()
    {
        return playerInSight;
    }
    
    // Gizmos for debugging
    void OnDrawGizmosSelected()
    {
        // Detection range
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, detectionRange);
        
        // Field of view
        Gizmos.color = Color.blue;
        Vector3 fovLine1 = Quaternion.AngleAxis(fieldOfView * 0.5f, transform.up) * transform.forward * detectionRange;
        Vector3 fovLine2 = Quaternion.AngleAxis(-fieldOfView * 0.5f, transform.up) * transform.forward * detectionRange;
        
        Gizmos.DrawLine(transform.position, transform.position + fovLine1);
        Gizmos.DrawLine(transform.position, transform.position + fovLine2);
        
        // Attack range
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, attackRange);
        
        // Patrol points
        if (patrolPoints != null)
        {
            Gizmos.color = Color.green;
            foreach (Transform point in patrolPoints)
            {
                if (point != null)
                    Gizmos.DrawSphere(point.position, 0.5f);
            }
        }
    }
}