using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class EnemySpawner : MonoBehaviour
{
    [Header("Spawn Settings")]
    [SerializeField] private GameObject[] enemyPrefabs; // Префабы врагов
    [SerializeField] private Transform[] spawnPoints; // Точки спавна
    [SerializeField] private int maxEnemies = 10; // Максимум врагов одновременно
    [SerializeField] private int enemiesPerWave = 3; // Врагов за волну
    [SerializeField] private float spawnDelay = 2f; // Задержка между спавном
    [SerializeField] private float waveDelay = 10f; // Задержка между волнами
    
    [Header("Spawn Conditions")]
    [SerializeField] private bool spawnOnStart = false; // Спавн при старте
    [SerializeField] private bool spawnOnTrigger = true; // Спавн при входе в триггер
    [SerializeField] private bool infiniteWaves = false; // Бесконечные волны
    [SerializeField] private int maxWaves = 3; // Максимум волн
    
    [Header("Distance Spawning")]
    [SerializeField] private bool spawnAtDistance = false; // Спавн когда игрок далеко
    [SerializeField] private float minSpawnDistance = 20f; // Минимальная дистанция
    [SerializeField] private float maxSpawnDistance = 50f; // Максимальная дистанция
    [SerializeField] private float checkInterval = 2f; // Как часто проверять
    
    [Header("Random Spawn")]
    [SerializeField] private bool randomSpawnArea = false; // Спавн в случайной области
    [SerializeField] private Vector3 spawnAreaCenter;
    [SerializeField] private Vector3 spawnAreaSize;
    [SerializeField] private LayerMask groundMask; // Для проверки поверхности
    
    [Header("Wave Configuration")]
    [SerializeField] private WaveConfig[] waves; // Настройки волн
    
    [Header("Horror Settings")]
    [SerializeField] private bool spawnOnSanityLow = false; // Спавн при низком рассудке
    [SerializeField] private float sanityThreshold = 30f;
    [SerializeField] private bool spawnInDarkness = false; // Только в темноте
    [SerializeField] private Light playerLight; // Свет игрока для проверки
    
    [Header("Visual Effects")]
    [SerializeField] private ParticleSystem spawnEffect; // Эффект при спавне
    [SerializeField] private AudioClip spawnSound; // Звук спавна
    [SerializeField] private Light spawnLight; // Свет при спавне
    [SerializeField] private float spawnLightDuration = 1f;
    
    [Header("UI Warning")]
    [SerializeField] private GameObject warningUI; // UI предупреждение
    [SerializeField] private float warningDuration = 2f;
    [SerializeField] private AudioClip warningSound;
    
    [Header("References")]
    [SerializeField] private Transform player;
    [SerializeField] private PlayerSanity playerSanity;
    
    // Private variables
    private List<GameObject> activeEnemies = new List<GameObject>();
    private int currentWave = 0;
    private int enemiesSpawnedThisWave = 0;
    private bool isSpawning = false;
    private float nextSpawnTime;
    private float nextWaveTime;
    private float nextDistanceCheck;
    private bool triggered = false;
    private Coroutine spawnRoutine;
    
    // Events
    public System.Action<int> OnWaveStarted; // Номер волны
    public System.Action<int> OnWaveCompleted; // Номер волны
    public System.Action<GameObject> OnEnemySpawned; // Враг
    public System.Action<GameObject> OnEnemyDied; // Враг
    public System.Action OnAllWavesCompleted;
    public System.Action OnSpawningStarted;
    public System.Action OnSpawningStopped;
    
    [System.Serializable]
    public class WaveConfig
    {
        public string waveName = "Wave 1";
        public int enemyCount = 5;
        public float spawnDelay = 2f;
        public GameObject[] enemyTypes; // Если пусто, использует общие префабы
        public float enemyHealthMultiplier = 1f;
        public float enemySpeedMultiplier = 1f;
        public bool spawnBoss = false;
        public GameObject bossPrefab;
        [TextArea] public string description;
    }
    
    void Start()
    {
        // Get references
        if (player == null)
            player = GameObject.FindGameObjectWithTag("Player")?.transform;
            
        if (playerSanity == null && player != null)
            playerSanity = player.GetComponent<PlayerSanity>();
            
        // Initialize
        if (spawnOnStart)
        {
            StartSpawning();
        }
        
        // Validate spawn points
        if (spawnPoints.Length == 0 && !randomSpawnArea)
        {
            Debug.LogError("EnemySpawner: No spawn points assigned!");
        }
    }
    
    void Update()
    {
        // Clean up dead enemies
        CleanupDeadEnemies();
        
        // Check distance spawning
        if (spawnAtDistance && !isSpawning && !triggered)
        {
            CheckDistanceSpawning();
        }
        
        // Check sanity spawning
        if (spawnOnSanityLow && !isSpawning && playerSanity != null)
        {
            CheckSanitySpawning();
        }
        
        // Continuous spawning logic
        if (isSpawning)
        {
            HandleSpawning();
        }
    }
    
    void HandleSpawning()
    {
        // Check if we reached max enemies
        if (activeEnemies.Count >= maxEnemies)
            return;
            
        // Check wave completion
        if (waves.Length > 0)
        {
            HandleWaveSpawning();
        }
        else
        {
            HandleSimpleSpawning();
        }
    }
    
    void HandleSimpleSpawning()
    {
        // Simple spawning without waves
        if (Time.time >= nextSpawnTime)
        {
            if (enemiesSpawnedThisWave < enemiesPerWave)
            {
                SpawnEnemy();
                enemiesSpawnedThisWave++;
                nextSpawnTime = Time.time + spawnDelay;
            }
            else if (infiniteWaves)
            {
                // Reset for next wave
                enemiesSpawnedThisWave = 0;
                nextWaveTime = Time.time + waveDelay;
            }
            else
            {
                // Stop spawning
                StopSpawning();
            }
        }
    }
    
    void HandleWaveSpawning()
    {
        if (currentWave >= waves.Length)
        {
            if (infiniteWaves)
                currentWave = 0;
            else
            {
                StopSpawning();
                OnAllWavesCompleted?.Invoke();
                return;
            }
        }
        
        WaveConfig currentWaveConfig = waves[currentWave];
        
        if (enemiesSpawnedThisWave < currentWaveConfig.enemyCount)
        {
            if (Time.time >= nextSpawnTime)
            {
                SpawnEnemyForWave(currentWaveConfig);
                enemiesSpawnedThisWave++;
                nextSpawnTime = Time.time + currentWaveConfig.spawnDelay;
            }
        }
        else
        {
            // Wave completed
            if (activeEnemies.Count == 0)
            {
                // All enemies in wave are dead
                OnWaveCompleted?.Invoke(currentWave);
                currentWave++;
                enemiesSpawnedThisWave = 0;
                nextWaveTime = Time.time + waveDelay;
                
                // Show warning for next wave
                if (currentWave < waves.Length)
                {
                    ShowWaveWarning(currentWave);
                }
            }
        }
    }
    
    void SpawnEnemy()
    {
        if (enemyPrefabs.Length == 0) return;
        
        // Choose spawn position
        Vector3 spawnPos = GetSpawnPosition();
        if (spawnPos == Vector3.zero) return;
        
        // Choose random enemy
        GameObject enemyPrefab = enemyPrefabs[Random.Range(0, enemyPrefabs.Length)];
        
        // Spawn enemy
        GameObject enemy = Instantiate(enemyPrefab, spawnPos, Quaternion.identity);
        
        // Setup enemy
        SetupEnemy(enemy);
        
        // Add to active list
        activeEnemies.Add(enemy);
        
        // Play effects
        PlaySpawnEffects(spawnPos);
        
        // Trigger event
        OnEnemySpawned?.Invoke(enemy);
    }
    
    void SpawnEnemyForWave(WaveConfig wave)
    {
        // Choose spawn position
        Vector3 spawnPos = GetSpawnPosition();
        if (spawnPos == Vector3.zero) return;
        
        GameObject enemyPrefab;
        
        // Choose enemy type
        if (wave.enemyTypes != null && wave.enemyTypes.Length > 0)
        {
            enemyPrefab = wave.enemyTypes[Random.Range(0, wave.enemyTypes.Length)];
        }
        else
        {
            enemyPrefab = enemyPrefabs[Random.Range(0, enemyPrefabs.Length)];
        }
        
        // Check for boss
        if (wave.spawnBoss && enemiesSpawnedThisWave == wave.enemyCount - 1 && wave.bossPrefab != null)
        {
            enemyPrefab = wave.bossPrefab;
        }
        
        // Spawn enemy
        GameObject enemy = Instantiate(enemyPrefab, spawnPos, Quaternion.identity);
        
        // Setup enemy with wave modifiers
        SetupEnemy(enemy, wave);
        
        // Add to active list
        activeEnemies.Add(enemy);
        
        // Play effects
        PlaySpawnEffects(spawnPos);
        
        // Trigger event
        OnEnemySpawned?.Invoke(enemy);
    }
    
    Vector3 GetSpawnPosition()
    {
        Vector3 spawnPos = Vector3.zero;
        
        if (randomSpawnArea)
        {
            // Random position in area
            for (int i = 0; i < 10; i++) // Try 10 times
            {
                Vector3 randomOffset = new Vector3(
                    Random.Range(-spawnAreaSize.x * 0.5f, spawnAreaSize.x * 0.5f),
                    0,
                    Random.Range(-spawnAreaSize.z * 0.5f, spawnAreaSize.z * 0.5f)
                );
                
                spawnPos = spawnAreaCenter + randomOffset;
                
                // Check if position is valid
                if (IsValidSpawnPosition(spawnPos))
                {
                    return spawnPos;
                }
            }
        }
        else if (spawnPoints.Length > 0)
        {
            // Random spawn point
            Transform spawnPoint = spawnPoints[Random.Range(0, spawnPoints.Length)];
            spawnPos = spawnPoint.position;
            
            if (IsValidSpawnPosition(spawnPos))
            {
                return spawnPos;
            }
        }
        
        // Check distance requirement
        if (spawnAtDistance && player != null)
        {
            float distanceToPlayer = Vector3.Distance(spawnPos, player.position);
            if (distanceToPlayer < minSpawnDistance || distanceToPlayer > maxSpawnDistance)
            {
                return Vector3.zero;
            }
        }
        
        // Check darkness requirement
        if (spawnInDarkness && playerLight != null)
        {
            // Проверяем, темно ли в точке спавна
            // Упрощенная проверка
            if (playerLight.intensity > 0.5f)
            {
                return Vector3.zero;
            }
        }
        
        return spawnPos;
    }
    
    bool IsValidSpawnPosition(Vector3 position)
    {
        // Check if position is on ground
        if (groundMask != 0)
        {
            RaycastHit hit;
            if (!Physics.Raycast(position + Vector3.up * 2f, Vector3.down, out hit, 5f, groundMask))
            {
                return false;
            }
            
            // Adjust position to ground level
            position = hit.point;
        }
        
        // Check if position is not inside obstacles
        Collider[] colliders = Physics.OverlapSphere(position, 1f);
        foreach (var col in colliders)
        {
            if (col.CompareTag("Obstacle") || col.CompareTag("Wall"))
            {
                return false;
            }
        }
        
        return true;
    }
    
    void SetupEnemy(GameObject enemy, WaveConfig wave = null)
    {
        // Add death listener
        EnemyHealth health = enemy.GetComponent<EnemyHealth>();
        if (health != null)
        {
            health.OnDeath += () => OnEnemyDiedInternal(enemy);
            
            // Apply wave health multiplier
            if (wave != null)
            {
                health.SetMaxHealth(health.GetMaxHealth() * wave.enemyHealthMultiplier);
            }
        }
        
        // Apply speed multiplier
        EnemyAI ai = enemy.GetComponent<EnemyAI>();
        if (ai != null && wave != null)
        {
            // You'd need to add speed multiplier property to EnemyAI
            // ai.speedMultiplier = wave.enemySpeedMultiplier;
        }
        
        // Set player reference
        EnemyAI enemyAI = enemy.GetComponent<EnemyAI>();
        if (enemyAI != null && player != null)
        {
            // If EnemyAI has a public method to set player
            // enemyAI.SetPlayer(player);
        }
    }
    
    void OnEnemyDiedInternal(GameObject enemy)
    {
        if (activeEnemies.Contains(enemy))
        {
            activeEnemies.Remove(enemy);
            OnEnemyDied?.Invoke(enemy);
        }
    }
    
    void CleanupDeadEnemies()
    {
        activeEnemies.RemoveAll(enemy => enemy == null);
    }
    
    void PlaySpawnEffects(Vector3 position)
    {
        // Particle effect
        if (spawnEffect != null)
        {
            ParticleSystem effect = Instantiate(spawnEffect, position, Quaternion.identity);
            effect.Play();
            Destroy(effect.gameObject, 2f);
        }
        
        // Sound
        if (spawnSound != null)
        {
            AudioSource.PlayClipAtPoint(spawnSound, position, 1f);
        }
        
        // Light effect
        if (spawnLight != null)
        {
            StartCoroutine(SpawnLightRoutine(position));
        }
    }
    
    IEnumerator SpawnLightRoutine(Vector3 position)
    {
        Light light = Instantiate(spawnLight, position, Quaternion.identity);
        float timer = 0f;
        
        while (timer < spawnLightDuration)
        {
            float intensity = Mathf.Lerp(1f, 0f, timer / spawnLightDuration);
            light.intensity = intensity;
            timer += Time.deltaTime;
            yield return null;
        }
        
        Destroy(light.gameObject);
    }
    
    void CheckDistanceSpawning()
    {
        if (player == null) return;
        
        nextDistanceCheck -= Time.deltaTime;
        if (nextDistanceCheck > 0) return;
        
        nextDistanceCheck = checkInterval;
        
        float distanceToPlayer = Vector3.Distance(transform.position, player.position);
        
        if (distanceToPlayer >= minSpawnDistance && distanceToPlayer <= maxSpawnDistance)
        {
            StartSpawning();
        }
    }
    
    void CheckSanitySpawning()
    {
        if (playerSanity == null) return;
        
        float sanityPercent = playerSanity.GetSanityNormalized() * 100f;
        
        if (sanityPercent <= sanityThreshold)
        {
            StartSpawning();
        }
    }
    
    void ShowWaveWarning(int waveNumber)
    {
        if (warningUI != null)
        {
            StartCoroutine(ShowWarningRoutine(waveNumber));
        }
        
        if (warningSound != null)
        {
            AudioSource.PlayClipAtPoint(warningSound, transform.position);
        }
    }
    
    IEnumerator ShowWarningRoutine(int waveNumber)
    {
        warningUI.SetActive(true);
        
        // Update text if needed
        // warningUI.GetComponent<Text>().text = "Волна " + (waveNumber + 1);
        
        yield return new WaitForSeconds(warningDuration);
        
        warningUI.SetActive(false);
    }
    
    // Public methods
    
    public void StartSpawning()
    {
        if (isSpawning) return;
        
        isSpawning = true;
        triggered = true;
        currentWave = 0;
        enemiesSpawnedThisWave = 0;
        nextSpawnTime = Time.time + spawnDelay;
        
        OnSpawningStarted?.Invoke();
        
        // Show first wave warning
        if (waves.Length > 0)
        {
            ShowWaveWarning(0);
        }
    }
    
    public void StopSpawning()
    {
        isSpawning = false;
        OnSpawningStopped?.Invoke();
    }
    
    public void ResetSpawner()
    {
        StopSpawning();
        
        // Clear all enemies
        foreach (var enemy in activeEnemies)
        {
            if (enemy != null)
                Destroy(enemy);
        }
        
        activeEnemies.Clear();
        currentWave = 0;
        enemiesSpawnedThisWave = 0;
        triggered = false;
    }
    
    public void SpawnImmediate(int count)
    {
        for (int i = 0; i < count; i++)
        {
            if (activeEnemies.Count >= maxEnemies) break;
            SpawnEnemy();
        }
    }
    
    public void SpawnEnemyAtPoint(int pointIndex)
    {
        if (pointIndex >= spawnPoints.Length) return;
        
        if (enemyPrefabs.Length == 0) return;
        
        Vector3 spawnPos = spawnPoints[pointIndex].position;
        
        GameObject enemyPrefab = enemyPrefabs[Random.Range(0, enemyPrefabs.Length)];
        GameObject enemy = Instantiate(enemyPrefab, spawnPos, Quaternion.identity);
        
        SetupEnemy(enemy);
        activeEnemies.Add(enemy);
        
        PlaySpawnEffects(spawnPos);
        OnEnemySpawned?.Invoke(enemy);
    }
    
    public int GetActiveEnemyCount()
    {
        return activeEnemies.Count;
    }
    
    public int GetCurrentWave()
    {
        return currentWave;
    }
    
    public float GetWaveProgress()
    {
        if (waves.Length == 0) return 0;
        if (currentWave >= waves.Length) return 1f;
        
        return (float)enemiesSpawnedThisWave / waves[currentWave].enemyCount;
    }
    
    public bool IsSpawning()
    {
        return isSpawning;
    }
    
    // Gizmos for visualization
    void OnDrawGizmosSelected()
    {
        // Spawn area
        if (randomSpawnArea)
        {
            Gizmos.color = new Color(1, 0, 0, 0.3f);
            Gizmos.DrawCube(spawnAreaCenter, spawnAreaSize);
        }
        
        // Spawn points
        if (spawnPoints != null)
        {
            Gizmos.color = Color.red;
            foreach (Transform point in spawnPoints)
            {
                if (point != null)
                {
                    Gizmos.DrawSphere(point.position, 0.5f);
                }
            }
        }
        
        // Distance ranges
        if (spawnAtDistance)
        {
            Gizmos.color = new Color(0, 1, 0, 0.1f);
            Gizmos.DrawWireSphere(transform.position, minSpawnDistance);
            
            Gizmos.color = new Color(1, 0, 0, 0.1f);
            Gizmos.DrawWireSphere(transform.position, maxSpawnDistance);
        }
    }
}

// Simple enemy health class for death events
public class EnemyHealth : MonoBehaviour
{
    [SerializeField] private float maxHealth = 100f;
    private float currentHealth;
    
    public System.Action OnDeath;
    
    void Start()
    {
        currentHealth = maxHealth;
    }
    
    public void TakeDamage(float damage)
    {
        currentHealth -= damage;
        
        if (currentHealth <= 0)
        {
            Die();
        }
    }
    
    void Die()
    {
        OnDeath?.Invoke();
        Destroy(gameObject);
    }
    
    public void SetMaxHealth(float multiplier)
    {
        maxHealth *= multiplier;
        currentHealth = maxHealth;
    }
    
    public float GetMaxHealth()
    {
        return maxHealth;
    }
}