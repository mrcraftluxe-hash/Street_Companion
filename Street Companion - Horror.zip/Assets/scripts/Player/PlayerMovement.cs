using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [Header("Movement Settings")]
    [SerializeField] private float walkSpeed = 4f;
    [SerializeField] private float runSpeed = 7f;
    [SerializeField] private float crouchSpeed = 2f;
    [SerializeField] private float sneakSpeed = 1.5f; // Крадучийся шаг (тихий режим)
    [SerializeField] private float acceleration = 10f;
    [SerializeField] private float deceleration = 10f;
    [SerializeField] private float airControl = 0.3f;
    
    [Header("Jump & Gravity")]
    [SerializeField] private float jumpForce = 5f;
    [SerializeField] private float gravity = -20f;
    [SerializeField] private float groundCheckDistance = 0.2f;
    [SerializeField] private LayerMask groundMask = ~0;
    [SerializeField] private float maxSlopeAngle = 45f;
    
    [Header("Stamina System")]
    [SerializeField] private float maxStamina = 100f;
    [SerializeField] private float currentStamina;
    [SerializeField] private float staminaDrainRate = 15f;
    [SerializeField] private float staminaRegenRate = 10f;
    [SerializeField] private float staminaRegenDelay = 1.5f;
    [SerializeField] private float exhaustedStaminaRegenDelay = 3f; // Задержка при истощении
    
    [Header("Crouch Settings")]
    [SerializeField] private float crouchHeight = 1f;
    [SerializeField] private float standingHeight = 2f;
    [SerializeField] private float crouchTransitionSpeed = 8f;
    [SerializeField] private float crouchCameraOffset = 0.5f;
    
    [Header("Footstep System")]
    [SerializeField] private AudioSource footstepAudio;
    [SerializeField] private float walkStepInterval = 0.5f;
    [SerializeField] private float runStepInterval = 0.3f;
    [SerializeField] private float crouchStepInterval = 0.8f;
    [SerializeField] private float sneakStepInterval = 1.2f;
    [SerializeField] private AudioClip[] concreteFootsteps;
    [SerializeField] private AudioClip[] woodFootsteps;
    [SerializeField] private AudioClip[] metalFootsteps;
    [SerializeField] private AudioClip[] carpetFootsteps;
    [SerializeField] private float footstepVolume = 0.5f;
    [SerializeField] private float footstepPitchVariation = 0.1f;
    
    [Header("Landing & Falling")]
    [SerializeField] private float hardLandingThreshold = 10f; // Скорость для жесткого приземления
    [SerializeField] private AudioClip landingSound;
    [SerializeField] private AudioClip hardLandingSound;
    [SerializeField] private float landingVolume = 0.5f;
    
    [Header("Slope Handling")]
    [SerializeField] private float slopeSlideSpeed = 5f;
    [SerializeField] private bool slideOnSteepSlopes = true;
    
    [Header("Horror Effects")]
    [SerializeField] private float fearMovementPenalty = 0.5f; // Замедление при страхе
    [SerializeField] private float sanityMovementMultiplier = 1f; // Множитель скорости при низком рассудке
    [SerializeField] private AnimationCurve sanitySpeedCurve;
    
    [Header("References")]
    [SerializeField] private Transform playerCamera;
    [SerializeField] private CharacterController characterController;
    
    // Private variables
    private Vector3 moveDirection;
    private Vector3 velocity;
    private Vector3 smoothedVelocity;
    private float currentSpeed;
    private float targetSpeed;
    private float currentStrideInterval;
    private float stepTimer;
    private float staminaRegenTimer;
    private bool isGrounded;
    private bool wasGroundedLastFrame;
    private bool isCrouching;
    private bool isRunning;
    private bool isSneaking; // Тихий режим (например, по Ctrl)
    private bool isExhausted;
    private float originalHeight;
    private Vector3 originalCameraPosition;
    private RaycastHit slopeHit;
    private float currentSlopeAngle;
    private float lastYPosition;
    private float fallDistance;
    private TerrainType currentTerrain = TerrainType.Concrete;
    
    // Public properties
    public bool IsRunning => isRunning && !isExhausted && !isCrouching && !isSneaking;
    public bool IsCrouching => isCrouching;
    public bool IsSneaking => isSneaking;
    public bool IsMoving => characterController.velocity.magnitude > 0.1f;
    public float CurrentSpeed => characterController.velocity.magnitude;
    public float StaminaPercent => currentStamina / maxStamina;
    public bool IsExhausted => isExhausted;
    
    // Terrain types for footstep sounds
    private enum TerrainType
    {
        Concrete,
        Wood,
        Metal,
        Carpet
    }
    
    void Start()
    {
        // Get components if not assigned
        if (characterController == null)
            characterController = GetComponent<CharacterController>();
            
        if (playerCamera == null && Camera.main != null)
            playerCamera = Camera.main.transform;
            
        // Initialize
        currentStamina = maxStamina;
        originalHeight = characterController.height;
        
        if (playerCamera != null)
            originalCameraPosition = playerCamera.localPosition;
            
        // Lock cursor
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
        
        // Store initial Y position for fall calculation
        lastYPosition = transform.position.y;
    }
    
    void Update()
    {
        // Ground check
        CheckGround();
        
        // Handle input and movement
        HandleMovementInput();
        
        // Handle jumping
        HandleJump();
        
        // Handle crouch
        HandleCrouch();
        
        // Handle sneak (silent mode)
        HandleSneak();
        
        // Apply gravity
        ApplyGravity();
        
        // Handle slope movement
        HandleSlopeMovement();
        
        // Move the character
        MoveCharacter();
        
        // Update stamina
        UpdateStamina();
        
        // Handle footsteps
        HandleFootsteps();
        
        // Handle landing
        HandleLanding();
        
        // Update state
        UpdatePlayerState();
    }
    
    void CheckGround()
    {
        // Store previous grounded state
        wasGroundedLastFrame = isGrounded;
        
        // Sphere cast for ground detection
        Vector3 spherePosition = transform.position - Vector3.up * (characterController.height * 0.5f - characterController.radius);
        isGrounded = Physics.CheckSphere(spherePosition, characterController.radius - 0.05f, groundMask);
        
        // Additional raycast for slope detection
        if (isGrounded)
        {
            RaycastHit hit;
            if (Physics.Raycast(transform.position, Vector3.down, out hit, groundCheckDistance + 0.1f, groundMask))
            {
                currentSlopeAngle = Vector3.Angle(Vector3.up, hit.normal);
                
                // Detect terrain type for footsteps
                DetectTerrainType(hit);
            }
        }
    }
    
    void DetectTerrainType(RaycastHit hit)
    {
        // Check by tag
        if (hit.collider.CompareTag("Wood"))
            currentTerrain = TerrainType.Wood;
        else if (hit.collider.CompareTag("Metal"))
            currentTerrain = TerrainType.Metal;
        else if (hit.collider.CompareTag("Carpet"))
            currentTerrain = TerrainType.Carpet;
        else
            currentTerrain = TerrainType.Concrete;
            
        // Можно расширить проверкой по имени материала
    }
    
    void HandleMovementInput()
    {
        // Get input
        float horizontal = Input.GetAxisRaw("Horizontal");
        float vertical = Input.GetAxisRaw("Vertical");
        
        // Calculate movement direction
        Vector3 inputDirection = new Vector3(horizontal, 0, vertical).normalized;
        
        if (inputDirection.magnitude >= 0.1f)
        {
            // Calculate target direction relative to player
            float targetAngle = Mathf.Atan2(inputDirection.x, inputDirection.z) * Mathf.Rad2Deg + transform.eulerAngles.y;
            Vector3 targetDirection = Quaternion.Euler(0, targetAngle, 0) * Vector3.forward;
            
            moveDirection = targetDirection;
        }
        else
        {
            moveDirection = Vector3.zero;
        }
        
        // Determine target speed based on state
        if (isCrouching)
        {
            targetSpeed = crouchSpeed;
        }
        else if (isSneaking)
        {
            targetSpeed = sneakSpeed;
        }
        else if (Input.GetKey(KeyCode.LeftShift) && !isExhausted && !isCrouching)
        {
            isRunning = true;
            targetSpeed = runSpeed;
        }
        else
        {
            isRunning = false;
            targetSpeed = walkSpeed;
        }
        
        // Apply horror penalties
        targetSpeed *= GetHorrorSpeedMultiplier();
        
        // Smooth speed
        if (moveDirection.magnitude > 0)
        {
            currentSpeed = Mathf.Lerp(currentSpeed, targetSpeed, acceleration * Time.deltaTime);
        }
        else
        {
            currentSpeed = Mathf.Lerp(currentSpeed, 0, deceleration * Time.deltaTime);
        }
    }
    
    float GetHorrorSpeedMultiplier()
    {
        float multiplier = 1f;
        
        // Fear penalty
        if (isExhausted)
            multiplier *= fearMovementPenalty;
            
        // Sanity effect (можно подключить из другой системы)
        multiplier *= sanitySpeedCurve.Evaluate(sanityMovementMultiplier);
        
        return multiplier;
    }
    
    void HandleJump()
    {
        if (Input.GetButtonDown("Jump") && isGrounded && !isCrouching && !isSneaking && currentSlopeAngle < maxSlopeAngle)
        {
            velocity.y = Mathf.Sqrt(jumpForce * -2f * gravity);
        }
    }
    
    void HandleCrouch()
    {
        if (Input.GetKeyDown(KeyCode.C) || Input.GetKeyDown(KeyCode.LeftControl))
        {
            isCrouching = !isCrouching;
            
            if (isCrouching)
                isSneaking = false; // Отключаем крадущийся режим
        }
        
        // Adjust character controller height
        float targetHeight = isCrouching ? crouchHeight : standingHeight;
        characterController.height = Mathf.Lerp(characterController.height, targetHeight, Time.deltaTime * crouchTransitionSpeed);
        
        // Adjust camera position
        if (playerCamera != null)
        {
            Vector3 targetCameraPos = originalCameraPosition;
            if (isCrouching)
                targetCameraPos.y = standingHeight - crouchHeight - crouchCameraOffset;
                
            playerCamera.localPosition = Vector3.Lerp(playerCamera.localPosition, targetCameraPos, Time.deltaTime * crouchTransitionSpeed);
        }
    }
    
    void HandleSneak()
    {
        // Активация тихого режима (например, по Alt)
        if (Input.GetKey(KeyCode.LeftAlt) && !isCrouching && isGrounded)
        {
            isSneaking = true;
            isRunning = false;
        }
        else if (Input.GetKeyUp(KeyCode.LeftAlt))
        {
            isSneaking = false;
        }
    }
    
    void ApplyGravity()
    {
        if (isGrounded && velocity.y < 0)
        {
            velocity.y = -2f; // Небольшая сила прижатия к земле
        }
        
        velocity.y += gravity * Time.deltaTime;
    }
    
    void HandleSlopeMovement()
    {
        if (!isGrounded || currentSlopeAngle <= maxSlopeAngle || !slideOnSteepSlopes) return;
        
        // Скольжение по крутым склонам
        velocity.x += (1f - currentSlopeAngle / 90f) * slopeSlideSpeed * slopeHit.normal.x * Time.deltaTime;
        velocity.z += (1f - currentSlopeAngle / 90f) * slopeSlideSpeed * slopeHit.normal.z * Time.deltaTime;
    }
    
    void MoveCharacter()
    {
        // Calculate movement
        Vector3 movement = moveDirection * currentSpeed;
        
        // Apply air control
        if (!isGrounded)
        {
            movement.x = Mathf.Lerp(velocity.x, movement.x, airControl);
            movement.z = Mathf.Lerp(velocity.z, movement.z, airControl);
        }
        
        // Combine with velocity
        Vector3 finalMovement = movement + velocity;
        
        // Move character
        characterController.Move(finalMovement * Time.deltaTime);
    }
    
    void UpdateStamina()
    {
        if (isRunning && IsMoving)
        {
            // Drain stamina
            currentStamina -= staminaDrainRate * Time.deltaTime;
            staminaRegenTimer = 0f;
            
            // Check if exhausted
            if (currentStamina <= 0)
            {
                currentStamina = 0;
                isExhausted = true;
            }
        }
        else
        {
            // Regenerate stamina
            staminaRegenTimer += Time.deltaTime;
            
            float regenDelay = isExhausted ? exhaustedStaminaRegenDelay : staminaRegenDelay;
            
            if (staminaRegenTimer >= regenDelay)
            {
                currentStamina += staminaRegenRate * Time.deltaTime;
                
                // Exit exhausted state
                if (currentStamina >= maxStamina * 0.3f)
                {
                    isExhausted = false;
                }
            }
        }
        
        // Clamp stamina
        currentStamina = Mathf.Clamp(currentStamina, 0, maxStamina);
    }
    
    void HandleFootsteps()
    {
        if (!isGrounded || !IsMoving)
        {
            stepTimer = 0f;
            return;
        }
        
        // Determine step interval based on state
        float stepInterval;
        if (isSneaking)
            stepInterval = sneakStepInterval;
        else if (isCrouching)
            stepInterval = crouchStepInterval;
        else if (isRunning)
            stepInterval = runStepInterval;
        else
            stepInterval = walkStepInterval;
            
        stepTimer -= Time.deltaTime;
        
        if (stepTimer <= 0f)
        {
            PlayFootstepSound();
            stepTimer = stepInterval;
        }
    }
    
    void PlayFootstepSound()
    {
        if (footstepAudio == null) return;
        
        AudioClip[] clips = GetFootstepClipsForTerrain();
        if (clips == null || clips.Length == 0) return;
        
        int randomIndex = Random.Range(0, clips.Length);
        footstepAudio.clip = clips[randomIndex];
        footstepAudio.volume = footstepVolume * (isSneaking ? 0.3f : (isCrouching ? 0.6f : 1f));
        footstepAudio.pitch = 1f + Random.Range(-footstepPitchVariation, footstepPitchVariation);
        footstepAudio.Play();
    }
    
    AudioClip[] GetFootstepClipsForTerrain()
    {
        switch (currentTerrain)
        {
            case TerrainType.Wood: return woodFootsteps;
            case TerrainType.Metal: return metalFootsteps;
            case TerrainType.Carpet: return carpetFootsteps;
            default: return concreteFootsteps;
        }
    }
    
    void HandleLanding()
    {
        // Calculate fall distance
        if (!isGrounded)
        {
            fallDistance = lastYPosition - transform.position.y;
        }
        else if (!wasGroundedLastFrame && isGrounded)
        {
            // Just landed
            float fallSpeed = Mathf.Abs(velocity.y);
            
            if (fallSpeed > hardLandingThreshold)
            {
                // Hard landing - play sound and maybe damage
                if (hardLandingSound != null)
                    AudioSource.PlayClipAtPoint(hardLandingSound, transform.position, landingVolume);
                    
                // Можно добавить урон или эффект
            }
            else if (fallDistance > 2f)
            {
                // Normal landing
                if (landingSound != null)
                    AudioSource.PlayClipAtPoint(landingSound, transform.position, landingVolume * 0.5f);
            }
            
            fallDistance = 0f;
        }
        
        // Update last Y position for fall calculation
        if (!isGrounded)
        {
            lastYPosition = transform.position.y;
        }
    }
    
    void UpdatePlayerState()
    {
        // Обновляем различные состояния игрока
        
        // Если игрок истощен, он не может бежать
        if (isExhausted)
            isRunning = false;
            
        // Нельзя красться во время бега или приседания
        if (isRunning || isCrouching)
            isSneaking = false;
    }
    
    // Public methods for other scripts
    
    public void AddStamina(float amount)
    {
        currentStamina = Mathf.Min(maxStamina, currentStamina + amount);
    }
    
    public void DrainStaminaInstant(float amount)
    {
        currentStamina = Mathf.Max(0, currentStamina - amount);
        staminaRegenTimer = 0f;
    }
    
    public void SetSanityMultiplier(float multiplier)
    {
        sanityMovementMultiplier = Mathf.Clamp01(multiplier);
    }
    
    public void ApplyFearEffect(float intensity)
    {
        // Временный эффект страха
        StartCoroutine(FearEffectRoutine(intensity));
    }
    
    private System.Collections.IEnumerator FearEffectRoutine(float intensity)
    {
        float originalSpeed = targetSpeed;
        float duration = 2f;
        float timer = 0f;
        
        while (timer < duration)
        {
            // Случайные спотыкания
            if (Random.value < 0.1f)
            {
                velocity += new Vector3(Random.Range(-1f, 1f), 0, Random.Range(-1f, 1f)) * intensity;
            }
            
            timer += Time.deltaTime;
            yield return null;
        }
    }
    
    // For UI
    public float GetStaminaNormalized()
    {
        return currentStamina / maxStamina;
    }
    
    public string GetMovementState()
    {
        if (!isGrounded) return "В воздухе";
        if (isSneaking) return "Крадётся";
        if (isCrouching) return "Присел";
        if (isRunning) return "Бежит";
        if (IsMoving) return "Идёт";
        return "Стоит";
    }
    
    void OnDrawGizmosSelected()
    {
        // Visualize ground check
        Gizmos.color = isGrounded ? Color.green : Color.red;
        Vector3 spherePosition = transform.position - Vector3.up * (characterController.height * 0.5f - characterController.radius);
        Gizmos.DrawWireSphere(spherePosition, characterController.radius - 0.05f);
    }
}