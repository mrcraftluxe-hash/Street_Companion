using UnityEngine;

public class PlayerFlashlight : MonoBehaviour
{
    [Header("Flashlight References")]
    [SerializeField] private Light flashlightLight;
    [SerializeField] private Transform flashlightTransform;
    [SerializeField] private GameObject flashlightModel;
    [SerializeField] private Animator flashlightAnimator;
    
    [Header("Battery System")]
    [SerializeField] private float maxBattery = 100f;
    [SerializeField] private float currentBattery;
    [SerializeField] private float drainRateNormal = 1f;
    [SerializeField] private float drainRateRunning = 2f;
    [SerializeField] private float drainRateFlickering = 3f;
    
    [Header("Flicker Effects")]
    [SerializeField] private float flickerThreshold = 20f; // Батарея ниже этого значения начинает мигать
    [SerializeField] private float criticalThreshold = 10f;
    [SerializeField] private float flickerSpeed = 10f;
    [SerializeField] private AnimationCurve flickerPattern;
    [SerializeField] private float randomFlickerChance = 0.02f; // Шанс случайного мерцания
    
    [Header("Light Settings")]
    [SerializeField] private float maxIntensity = 8f;
    [SerializeField] private float minIntensity = 1f;
    [SerializeField] private float maxRange = 30f;
    [SerializeField] private float minRange = 10f;
    [SerializeField] private float spotAngle = 45f;
    
    [Header("Audio")]
    [SerializeField] private AudioSource audioSource;
    [SerializeField] private AudioClip toggleOnSound;
    [SerializeField] private AudioClip toggleOffSound;
    [SerializeField] private AudioClip flickerSound;
    [SerializeField] private AudioClip batteryLowSound;
    [SerializeField] private AudioClip batteryCriticalSound;
    [SerializeField] private AudioClip batteryDeadSound;
    
    [Header("UI")]
    [SerializeField] private UnityEngine.UI.Slider batterySlider;
    [SerializeField] private UnityEngine.UI.Image batteryFillImage;
    [SerializeField] private Color batteryNormalColor = Color.green;
    [SerializeField] private Color batteryLowColor = Color.yellow;
    [SerializeField] private Color batteryCriticalColor = Color.red;
    
    [Header("Effects")]
    [SerializeField] private ParticleSystem batterySparkEffect;
    [SerializeField] private Light flickerLight; // Дополнительный свет для эффектов
    
    // Private variables
    private bool isOn = false;
    private bool isFlickering = false;
    private float originalIntensity;
    private float originalRange;
    private float flickerTimer = 0f;
    private float lowBatteryTimer = 0f;
    private float randomFlickerTimer = 0f;
    private PlayerController playerController;
    private float targetIntensity;
    private float targetRange;
    
    // Events for other systems
    public System.Action OnFlashlightToggled;
    public System.Action OnBatteryLow;
    public System.Action OnBatteryCritical;
    public System.Action OnBatteryDead;
    
    void Start()
    {
        // Initialize battery
        currentBattery = maxBattery;
        
        // Get components if not assigned
        if (flashlightLight == null)
            flashlightLight = GetComponent<Light>();
            
        if (audioSource == null)
            audioSource = GetComponent<AudioSource>();
            
        if (playerController == null)
            playerController = GetComponentInParent<PlayerController>();
            
        // Store original values
        if (flashlightLight != null)
        {
            originalIntensity = flashlightLight.intensity;
            originalRange = flashlightLight.range;
            targetIntensity = originalIntensity;
            targetRange = originalRange;
            
            // Start with light off
            flashlightLight.enabled = false;
        }
        
        // Hide model initially if needed
        if (flashlightModel != null)
            flashlightModel.SetActive(false);
            
        // Setup UI
        UpdateBatteryUI();
    }
    
    void Update()
    {
        // Toggle flashlight with F key
        if (Input.GetKeyDown(KeyCode.F))
        {
            ToggleFlashlight();
        }
        
        // Quick recharge for testing (remove in final build)
        if (Input.GetKeyDown(KeyCode.R) && Debug.isDebugBuild)
        {
            RechargeBattery(maxBattery);
        }
        
        if (isOn)
        {
            // Drain battery based on player state
            float drainRate = GetCurrentDrainRate();
            DrainBattery(drainRate * Time.deltaTime);
            
            // Handle battery effects
            HandleBatteryEffects();
            
            // Handle flickering
            HandleFlickering();
            
            // Update light properties based on battery
            UpdateLightProperties();
            
            // Random flicker for atmosphere
            HandleRandomFlicker();
            
            // Check if battery died
            if (currentBattery <= 0)
            {
                currentBattery = 0;
                ForceTurnOff();
                OnBatteryDead?.Invoke();
                PlaySound(batteryDeadSound);
            }
        }
        
        // Update UI
        UpdateBatteryUI();
    }
    
    private float GetCurrentDrainRate()
    {
        float rate = drainRateNormal;
        
        // Drain faster if player is running
        if (playerController != null && playerController.IsRunning())
        {
            rate = drainRateRunning;
        }
        
        // Drain even faster if flickering
        if (isFlickering)
        {
            rate = drainRateFlickering;
        }
        
        return rate;
    }
    
    private void DrainBattery(float amount)
    {
        currentBattery = Mathf.Max(0, currentBattery - amount);
    }
    
    public void RechargeBattery(float amount)
    {
        currentBattery = Mathf.Min(maxBattery, currentBattery + amount);
        
        // Reset timers and flags
        lowBatteryTimer = 0f;
        isFlickering = false;
        
        // Update UI
        UpdateBatteryUI();
    }
    
    private void HandleBatteryEffects()
    {
        // Check battery thresholds
        if (currentBattery <= criticalThreshold)
        {
            if (!isFlickering)
            {
                OnBatteryCritical?.Invoke();
                PlaySound(batteryCriticalSound);
            }
            isFlickering = true;
        }
        else if (currentBattery <= flickerThreshold)
        {
            isFlickering = true;
            
            // Periodic low battery warning
            lowBatteryTimer -= Time.deltaTime;
            if (lowBatteryTimer <= 0)
            {
                OnBatteryLow?.Invoke();
                PlaySound(batteryLowSound);
                lowBatteryTimer = 8f; // Warn every 8 seconds
            }
        }
        else
        {
            isFlickering = false;
            lowBatteryTimer = 0f;
        }
    }
    
    private void HandleFlickering()
    {
        if (!isFlickering || flashlightLight == null)
        {
            // Smoothly return to normal
            targetIntensity = originalIntensity;
            targetRange = originalRange;
            return;
        }
        
        // Complex flicker pattern
        flickerTimer += Time.deltaTime * flickerSpeed;
        
        // Use different patterns based on battery level
        float flickerAmount;
        if (currentBattery <= criticalThreshold)
        {
            // Critical battery - chaotic flicker
            flickerAmount = Mathf.PerlinNoise(flickerTimer, 0) * 0.8f + 0.2f;
        }
        else
        {
            // Low battery - rhythmic flicker
            flickerAmount = flickerPattern.Evaluate(Mathf.PingPong(flickerTimer, 1f));
        }
        
        // Add randomness
        flickerAmount *= Random.Range(0.7f, 1.3f);
        
        // Calculate target values
        targetIntensity = originalIntensity * (0.3f + flickerAmount * 0.7f);
        targetRange = originalRange * (0.5f + flickerAmount * 0.5f);
        
        // Play flicker sound occasionally
        if (Random.value < 0.01f && flickerSound != null)
        {
            audioSource.PlayOneShot(flickerSound, 0.3f);
            
            // Spawn spark effect
            if (batterySparkEffect != null)
                batterySparkEffect.Play();
        }
    }
    
    private void HandleRandomFlicker()
    {
        // Random atmospheric flicker even on full battery
        if (!isFlickering && Random.value < randomFlickerChance * Time.deltaTime * 60f)
        {
            StartCoroutine(RandomFlickerRoutine());
        }
    }
    
    private System.Collections.IEnumerator RandomFlickerRoutine()
    {
        if (flashlightLight == null) yield break;
        
        float originalIntensity = flashlightLight.intensity;
        float flickerDuration = Random.Range(0.1f, 0.3f);
        float timer = 0f;
        
        while (timer < flickerDuration)
        {
            flashlightLight.intensity = originalIntensity * Random.Range(0.2f, 1f);
            timer += Time.deltaTime;
            yield return null;
        }
        
        flashlightLight.intensity = originalIntensity;
    }
    
    private void UpdateLightProperties()
    {
        if (flashlightLight == null) return;
        
        // Smoothly interpolate to target values
        flashlightLight.intensity = Mathf.Lerp(flashlightLight.intensity, targetIntensity, Time.deltaTime * 5f);
        flashlightLight.range = Mathf.Lerp(flashlightLight.range, targetRange, Time.deltaTime * 5f);
        
        // Adjust color based on battery
        float batteryPercent = currentBattery / maxBattery;
        flashlightLight.color = Color.Lerp(Color.red, Color.white, batteryPercent);
        
        // Flicker light for effects
        if (flickerLight != null)
        {
            flickerLight.intensity = flashlightLight.intensity * 0.5f;
            flickerLight.enabled = flashlightLight.enabled;
        }
    }
    
    public void ToggleFlashlight()
    {
        SetFlashlightState(!isOn);
    }
    
    private void SetFlashlightState(bool state)
    {
        if (state && currentBattery <= 0)
        {
            // Can't turn on if battery is dead
            PlaySound(batteryDeadSound);
            return;
        }
        
        isOn = state;
        
        // Toggle light
        if (flashlightLight != null)
            flashlightLight.enabled = isOn;
            
        // Toggle model
        if (flashlightModel != null)
            flashlightModel.SetActive(isOn);
            
        // Play animation
        if (flashlightAnimator != null)
            flashlightAnimator.SetBool("FlashlightOn", isOn);
            
        // Play sound
        PlaySound(isOn ? toggleOnSound : toggleOffSound);
        
        // Invoke event
        OnFlashlightToggled?.Invoke();
        
        // Reset flicker state
        isFlickering = false;
        flickerTimer = 0f;
        
        // Reset to normal values
        targetIntensity = originalIntensity;
        targetRange = originalRange;
    }
    
    private void ForceTurnOff()
    {
        isOn = false;
        
        if (flashlightLight != null)
            flashlightLight.enabled = false;
            
        if (flashlightModel != null)
            flashlightModel.SetActive(false);
            
        if (flashlightAnimator != null)
            flashlightAnimator.SetBool("FlashlightOn", false);
            
        OnFlashlightToggled?.Invoke();
    }
    
    private void PlaySound(AudioClip clip)
    {
        if (clip != null && audioSource != null)
        {
            audioSource.PlayOneShot(clip);
        }
    }
    
    private void UpdateBatteryUI()
    {
        if (batterySlider != null)
        {
            batterySlider.value = currentBattery / maxBattery;
        }
        
        if (batteryFillImage != null)
        {
            float percent = currentBattery / maxBattery;
            
            if (percent <= criticalThreshold / maxBattery)
                batteryFillImage.color = batteryCriticalColor;
            else if (percent <= flickerThreshold / maxBattery)
                batteryFillImage.color = batteryLowColor;
            else
                batteryFillImage.color = batteryNormalColor;
        }
    }
    
    // Public methods for other scripts
    
    public float GetBatteryPercent()
    {
        return currentBattery / maxBattery;
    }
    
    public float GetCurrentBattery()
    {
        return currentBattery;
    }
    
    public bool IsFlashlightOn()
    {
        return isOn;
    }
    
    public bool IsBatteryLow()
    {
        return currentBattery <= flickerThreshold;
    }
    
    public bool IsBatteryCritical()
    {
        return currentBattery <= criticalThreshold;
    }
    
    public void AddBatteryBattery(float amount) // Переименовал чтобы не конфликтовать с RechargeBattery
    {
        RechargeBattery(amount);
    }
    
    // Call this when player picks up battery
    public void PickupBattery(float amount)
    {
        RechargeBattery(amount);
        
        // Optional: play pickup sound
        // PlaySound(batteryPickupSound);
    }
}