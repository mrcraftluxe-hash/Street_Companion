using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PlayerSanity : MonoBehaviour
{
    [Header("Sanity Settings")]
    [SerializeField] private float maxSanity = 100f;
    [SerializeField] private float currentSanity;
    [SerializeField] private float sanityDrainRate = 1f; // Естественная убыль в темноте
    [SerializeField] private float sanityRegenRate = 2f; // Восстановление на свету
    
    [Header("Sanity Thresholds")]
    [SerializeField] private float mildThreshold = 70f; // Легкое беспокойство
    [SerializeField] private float moderateThreshold = 40f; // Среднее помутнение
    [SerializeField] private float severeThreshold = 20f; // Тяжелое безумие
    [SerializeField] private float criticalThreshold = 10f; // Критическое состояние
    
    [Header("Darkness Effects")]
    [SerializeField] private float darknessDrainMultiplier = 2f; // Ускоренная потеря в темноте
    [SerializeField] private Light playerLight; // Ссылка на свет игрока
    [SerializeField] private float minLightIntensityForRegen = 0.5f; // Минимальная яркость для восстановления
    [SerializeField] private LayerMask lightBlockingMask; // Что блокирует свет
    
    [Header("Visual Effects")]
    [SerializeField] private Camera playerCamera;
    [SerializeField] private Material sanityMaterial; // Пост-обработка
    [SerializeField] private AnimationCurve vignetteIntensity;
    [SerializeField] private AnimationCurve distortionIntensity;
    [SerializeField] private AnimationCurve noiseIntensity;
    [SerializeField] private AnimationCurve colorSaturation;
    
    [Header("Audio Effects")]
    [SerializeField] private AudioSource sanityAudioSource;
    [SerializeField] private AudioSource heartbeatAudioSource;
    [SerializeField] private AudioClip[] whispersClips; // Шепоты
    [SerializeField] private AudioClip heartbeatNormal;
    [SerializeField] private AudioClip heartbeatFast;
    [SerializeField] private AudioClip heartbeatCritical;
    [SerializeField] private float whisperInterval = 5f;
    [SerializeField] private AnimationCurve heartbeatPitch;
    
    [Header("Hallucinations")]
    [SerializeField] private GameObject[] hallucinationPrefabs; // Галлюцинации (враги, тени)
    [SerializeField] private float hallucinationChance = 0.1f;
    [SerializeField] private float hallucinationMaxDistance = 10f;
    [SerializeField] private LayerMask hallucinationIgnoreMask;
    
    [Header("Screen Effects")]
    [SerializeField] private float blinkIntensity = 0.5f; // Моргание при падении рассудка
    [SerializeField] private float blinkSpeed = 2f;
    [SerializeField] private AnimationCurve blinkCurve;
    
    [Header("Movement Effects")]
    [SerializeField] private PlayerMovement playerMovement; // Ссылка на движение
    [SerializeField] private AnimationCurve speedMultiplierCurve;
    [SerializeField] private float maxHeadRandomness = 2f; // Случайные движения головы
    
    [Header("Sanity Events")]
    [SerializeField] private UnityEvent OnSanityMild; // Событие при легком безумии
    [SerializeField] private UnityEvent OnSanityModerate; // Событие при среднем
    [SerializeField] private UnityEvent OnSanitySevere; // При тяжелом
    [SerializeField] private UnityEvent OnSanityCritical; // Критическое
    [SerializeField] private UnityEvent OnSanityZero; // Полная потеря рассудка
    
    // Private variables
    private float sanityLevel;
    private float targetSanity;
    private float whisperTimer;
    private float hallucinationTimer;
    private float randomHeadTimer;
    private Vector3 originalCameraPosition;
    private Quaternion originalCameraRotation;
    private List<GameObject> activeHallucinations = new List<GameObject>();
    private SanityState currentState = SanityState.Normal;
    private bool isInDarkness;
    private float darknessCheckTimer;
    private float sanityDropTimer;
    private float lastSanityLevel;
    
    // Events for other systems
    public System.Action<float> OnSanityChanged;
    public System.Action<SanityState> OnSanityStateChanged;
    
    public enum SanityState
    {
        Normal,     // > 70
        Mild,       // 40-70
        Moderate,   // 20-40
        Severe,     // 10-20
        Critical    // < 10
    }
    
    void Start()
    {
        // Initialize
        currentSanity = maxSanity;
        targetSanity = maxSanity;
        lastSanityLevel = maxSanity;
        
        // Get components if not assigned
        if (playerCamera == null)
            playerCamera = GetComponent<Camera>();
            
        if (playerMovement == null)
            playerMovement = GetComponent<PlayerMovement>();
            
        if (sanityAudioSource == null)
            sanityAudioSource = GetComponent<AudioSource>();
            
        // Store original camera values
        if (playerCamera != null)
        {
            originalCameraPosition = playerCamera.transform.localPosition;
            originalCameraRotation = playerCamera.transform.localRotation;
        }
        
        // Start timers
        whisperTimer = whisperInterval;
        hallucinationTimer = Random.Range(5f, 15f);
        randomHeadTimer = Random.Range(2f, 5f);
        
        // Set initial state
        UpdateSanityState();
    }
    
    void Update()
    {
        // Calculate sanity changes
        CalculateSanityChange();
        
        // Smooth sanity change
        currentSanity = Mathf.Lerp(currentSanity, targetSanity, Time.deltaTime * 2f);
        
        // Check for state changes
        if (Mathf.Abs(currentSanity - lastSanityLevel) > 1f)
        {
            lastSanityLevel = currentSanity;
            OnSanityChanged?.Invoke(currentSanity / maxSanity);
            UpdateSanityState();
        }
        
        // Apply effects based on sanity
        ApplyVisualEffects();
        ApplyAudioEffects();
        ApplyMovementEffects();
        
        // Handle special effects
        HandleWhispers();
        HandleHallucinations();
        HandleRandomHeadMovements();
        
        // Check darkness
        CheckDarkness();
    }
    
    void CalculateSanityChange()
    {
        float delta = 0f;
        
        // Check if player is in darkness
        if (IsInDarkness())
        {
            // Lose sanity in darkness
            delta -= sanityDrainRate * darknessDrainMultiplier * Time.deltaTime;
        }
        else
        {
            // Regain sanity in light
            delta += sanityRegenRate * Time.deltaTime;
        }
        
        // Additional drain from recent scares
        delta -= GetFearDrainRate() * Time.deltaTime;
        
        // Apply delta
        targetSanity = Mathf.Clamp(targetSanity + delta, 0, maxSanity);
    }
    
    bool IsInDarkness()
    {
        // Simplified darkness check
        // В реальном проекте используйте LightProbes или SampleLight
        if (playerLight == null) return true;
        
        float lightIntensity = playerLight.intensity;
        
        // Check if player is in shadow
        if (Physics.Raycast(transform.position, -playerLight.transform.forward, out RaycastHit hit, 10f, lightBlockingMask))
        {
            return true;
        }
        
        return lightIntensity < minLightIntensityForRegen;
    }
    
    void CheckDarkness()
    {
        darknessCheckTimer -= Time.deltaTime;
        
        if (darknessCheckTimer <= 0)
        {
            isInDarkness = IsInDarkness();
            darknessCheckTimer = 0.5f; // Check twice per second
        }
    }
    
    float GetFearDrainRate()
    {
        // Дополнительная потеря от страха (можно связать с врагами)
        float fearRate = 0f;
        
        // Check if enemies are nearby
        Collider[] nearbyColliders = Physics.OverlapSphere(transform.position, 15f);
        foreach (var col in nearbyColliders)
        {
            if (col.CompareTag("Enemy"))
            {
                float distance = Vector3.Distance(transform.position, col.transform.position);
                fearRate += (15f - distance) * 0.5f;
            }
        }
        
        return Mathf.Clamp(fearRate, 0, 5f);
    }
    
    void UpdateSanityState()
    {
        SanityState newState;
        
        if (currentSanity >= mildThreshold)
            newState = SanityState.Normal;
        else if (currentSanity >= moderateThreshold)
            newState = SanityState.Mild;
        else if (currentSanity >= severeThreshold)
            newState = SanityState.Moderate;
        else if (currentSanity >= criticalThreshold)
            newState = SanityState.Severe;
        else
            newState = SanityState.Critical;
            
        if (newState != currentState)
        {
            currentState = newState;
            OnSanityStateChanged?.Invoke(currentState);
            
            // Trigger Unity Events
            switch (currentState)
            {
                case SanityState.Mild:
                    OnSanityMild?.Invoke();
                    break;
                case SanityState.Moderate:
                    OnSanityModerate?.Invoke();
                    break;
                case SanityState.Severe:
                    OnSanitySevere?.Invoke();
                    break;
                case SanityState.Critical:
                    OnSanityCritical?.Invoke();
                    break;
            }
            
            // Check for zero
            if (currentSanity <= 0)
            {
                OnSanityZero?.Invoke();
                // Game over or special effect
            }
        }
    }
    
    void ApplyVisualEffects()
    {
        if (sanityMaterial == null || playerCamera == null) return;
        
        float normalizedSanity = currentSanity / maxSanity;
        
        // Apply post-processing effects
        sanityMaterial.SetFloat("_VignetteIntensity", vignetteIntensity.Evaluate(1f - normalizedSanity));
        sanityMaterial.SetFloat("_DistortionIntensity", distortionIntensity.Evaluate(1f - normalizedSanity));
        sanityMaterial.SetFloat("_NoiseIntensity", noiseIntensity.Evaluate(1f - normalizedSanity));
        sanityMaterial.SetFloat("_Saturation", colorSaturation.Evaluate(normalizedSanity));
        
        // Blink effect at low sanity
        if (currentSanity < severeThreshold)
        {
            float blink = Mathf.Sin(Time.time * blinkSpeed) * blinkIntensity;
            sanityMaterial.SetFloat("_BlinkIntensity", blink * (1f - normalizedSanity));
        }
    }
    
    void ApplyAudioEffects()
    {
        float normalizedSanity = currentSanity / maxSanity;
        
        // Heartbeat
        if (heartbeatAudioSource != null)
        {
            if (currentSanity < moderateThreshold)
            {
                if (!heartbeatAudioSource.isPlaying)
                {
                    heartbeatAudioSource.clip = currentSanity < criticalThreshold ? heartbeatCritical : 
                                                (currentSanity < severeThreshold ? heartbeatFast : heartbeatNormal);
                    heartbeatAudioSource.Play();
                }
                
                heartbeatAudioSource.pitch = heartbeatPitch.Evaluate(1f - normalizedSanity);
                heartbeatAudioSource.volume = 1f - normalizedSanity;
            }
            else
            {
                heartbeatAudioSource.Stop();
            }
        }
    }
    
    void ApplyMovementEffects()
    {
        if (playerMovement == null) return;
        
        float normalizedSanity = currentSanity / maxSanity;
        float speedMultiplier = speedMultiplierCurve.Evaluate(normalizedSanity);
        
        // Apply speed penalty
        playerMovement.SetSanityMultiplier(speedMultiplier);
    }
    
    void HandleWhispers()
    {
        if (currentSanity > moderateThreshold) return;
        
        whisperTimer -= Time.deltaTime;
        
        if (whisperTimer <= 0 && whispersClips.Length > 0 && sanityAudioSource != null)
        {
            int randomIndex = Random.Range(0, whispersClips.Length);
            sanityAudioSource.PlayOneShot(whispersClips[randomIndex], 0.3f * (1f - currentSanity / maxSanity));
            
            // Random interval based on sanity
            whisperTimer = whisperInterval * (currentSanity / maxSanity) + Random.Range(-1f, 1f);
        }
    }
    
    void HandleHallucinations()
    {
        if (currentSanity > moderateThreshold || hallucinationPrefabs.Length == 0) return;
        
        hallucinationTimer -= Time.deltaTime;
        
        if (hallucinationTimer <= 0)
        {
            // Chance to spawn hallucination
            float chance = hallucinationChance * (1f - currentSanity / maxSanity);
            
            if (Random.value < chance)
            {
                SpawnHallucination();
            }
            
            // Reset timer
            hallucinationTimer = Random.Range(3f, 10f) * (currentSanity / maxSanity);
        }
        
        // Update existing hallucinations
        for (int i = activeHallucinations.Count - 1; i >= 0; i--)
        {
            if (activeHallucinations[i] == null)
            {
                activeHallucinations.RemoveAt(i);
                continue;
            }
            
            // Fade out and destroy after time
            Hallucination hallucination = activeHallucinations[i].GetComponent<Hallucination>();
            if (hallucination != null)
            {
                if (hallucination.IsExpired())
                {
                    Destroy(activeHallucinations[i]);
                    activeHallucinations.RemoveAt(i);
                }
            }
        }
    }
    
    void SpawnHallucination()
    {
        if (hallucinationPrefabs.Length == 0) return;
        
        // Find spawn position
        Vector3 spawnPos = FindHallucinationSpawnPosition();
        if (spawnPos == Vector3.zero) return;
        
        // Random prefab
        int randomIndex = Random.Range(0, hallucinationPrefabs.Length);
        GameObject hallucination = Instantiate(hallucinationPrefabs[randomIndex], spawnPos, Quaternion.identity);
        
        // Add hallucination component
        Hallucination comp = hallucination.AddComponent<Hallucination>();
        comp.Initialize(Random.Range(2f, 5f)); // Lifetime
        
        activeHallucinations.Add(hallucination);
    }
    
    Vector3 FindHallucinationSpawnPosition()
    {
        for (int i = 0; i < 10; i++)
        {
            Vector3 randomDir = Random.insideUnitSphere * hallucinationMaxDistance;
            randomDir.y = 0;
            
            Vector3 spawnPos = transform.position + randomDir;
            
            // Check if position is valid (not inside walls)
            if (!Physics.CheckSphere(spawnPos, 1f, hallucinationIgnoreMask))
            {
                // Check line of sight
                if (!Physics.Linecast(transform.position, spawnPos, out RaycastHit hit, hallucinationIgnoreMask))
                {
                    return spawnPos;
                }
            }
        }
        
        return Vector3.zero;
    }
    
    void HandleRandomHeadMovements()
    {
        if (currentSanity > mildThreshold || playerCamera == null) return;
        
        randomHeadTimer -= Time.deltaTime;
        
        if (randomHeadTimer <= 0)
        {
            // Random head jerk
            float intensity = maxHeadRandomness * (1f - currentSanity / maxSanity);
            
            Vector3 randomRotation = new Vector3(
                Random.Range(-intensity, intensity),
                Random.Range(-intensity, intensity),
                Random.Range(-intensity, intensity)
            );
            
            StartCoroutine(HeadJerkRoutine(randomRotation));
            
            randomHeadTimer = Random.Range(1f, 3f);
        }
    }
    
    IEnumerator HeadJerkRoutine(Vector3 targetRotation)
    {
        float duration = 0.2f;
        float timer = 0f;
        Quaternion startRot = playerCamera.transform.localRotation;
        Quaternion targetRot = startRot * Quaternion.Euler(targetRotation);
        
        while (timer < duration)
        {
            playerCamera.transform.localRotation = Quaternion.Slerp(startRot, targetRot, timer / duration);
            timer += Time.deltaTime;
            yield return null;
        }
        
        // Return to normal
        timer = 0f;
        while (timer < duration)
        {
            playerCamera.transform.localRotation = Quaternion.Slerp(targetRot, originalCameraRotation, timer / duration);
            timer += Time.deltaTime;
            yield return null;
        }
        
        playerCamera.transform.localRotation = originalCameraRotation;
    }
    
    // Public methods for other scripts
    
    public void AddSanity(float amount)
    {
        targetSanity = Mathf.Min(maxSanity, targetSanity + amount);
    }
    
    public void DrainSanity(float amount)
    {
        targetSanity = Mathf.Max(0, targetSanity - amount);
        
        // Immediate effect
        StartCoroutine(SanityDropEffect(amount));
    }
    
    IEnumerator SanityDropEffect(float amount)
    {
        float intensity = amount / maxSanity;
        
        // Screen flash
        if (sanityMaterial != null)
        {
            sanityMaterial.SetFloat("_FlashIntensity", intensity);
            yield return new WaitForSeconds(0.1f);
            sanityMaterial.SetFloat("_FlashIntensity", 0f);
        }
        
        // Sound
        if (sanityAudioSource != null)
        {
            sanityAudioSource.PlayOneShot(whispersClips[Random.Range(0, whispersClips.Length)], intensity);
        }
    }
    
    public float GetSanityNormalized()
    {
        return currentSanity / maxSanity;
    }
    
    public SanityState GetSanityState()
    {
        return currentState;
    }
    
    public string GetSanityStateName()
    {
        switch (currentState)
        {
            case SanityState.Normal: return "Норма";
            case SanityState.Mild: return "Беспокойство";
            case SanityState.Moderate: return "Смятение";
            case SanityState.Severe: return "Безумие";
            case SanityState.Critical: return "Критическое";
            default: return "Неизвестно";
        }
    }
    
    // Call this when player sees something scary
    public void Scare(float intensity)
    {
        DrainSanity(intensity * 10f);
        
        // Additional effects
        StartCoroutine(ScareRoutine(intensity));
    }
    
    IEnumerator ScareRoutine(float intensity)
    {
        // Freeze movement briefly
        if (playerMovement != null)
        {
            float originalSpeed = playerMovement.CurrentSpeed;
            playerMovement.enabled = false;
            yield return new WaitForSeconds(0.1f * intensity);
            playerMovement.enabled = true;
        }
    }
    
    void OnDestroy()
    {
        // Clean up hallucinations
        foreach (var hallucination in activeHallucinations)
        {
            if (hallucination != null)
                Destroy(hallucination);
        }
    }
}

// Helper class for hallucinations
public class Hallucination : MonoBehaviour
{
    private float lifetime;
    private float timer;
    private Material material;
    private float fadeStart;
    
    void Start()
    {
        material = GetComponentInChildren<Renderer>()?.material;
        fadeStart = lifetime * 0.7f;
    }
    
    public void Initialize(float life)
    {
        lifetime = life;
        timer = 0f;
    }
    
    void Update()
    {
        timer += Time.deltaTime;
        
        // Fade out
        if (material != null && timer > fadeStart)
        {
            float alpha = 1f - ((timer - fadeStart) / (lifetime - fadeStart));
            Color color = material.color;
            color.a = alpha;
            material.color = color;
        }
    }
    
    public bool IsExpired()
    {
        return timer >= lifetime;
    }
}