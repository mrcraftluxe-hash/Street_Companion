using UnityEngine;

public class Flashlight : MonoBehaviour
{
    [Header("Light Components")]
    [SerializeField] private Light flashlightLight;
    [SerializeField] private GameObject flashlightModel; // 3D модель фонарика
    [SerializeField] private AudioSource audioSource;
    
    [Header("Battery Settings")]
    [SerializeField] private float maxBatteryLife = 100f;
    [SerializeField] private float batteryDrainRate = 1f; // в секунду
    [SerializeField] private float batteryLowThreshold = 20f;
    [SerializeField] private float batteryCriticalThreshold = 10f;
    
    [Header("Flicker Settings")]
    [SerializeField] private float flickerIntensity = 0.3f;
    [SerializeField] private float flickerSpeed = 5f;
    [SerializeField] private AnimationCurve flickerCurve = AnimationCurve.EaseInOut(0, 0, 1, 1);
    
    [Header("Intensity Settings")]
    [SerializeField] private float maxIntensity = 5f;
    [SerializeField] private float minIntensity = 2f;
    [SerializeField] private float intensityDropRate = 0.5f; // как быстро тускнеет при разрядке
    
    [Header("Sounds")]
    [SerializeField] private AudioClip turnOnSound;
    [SerializeField] private AudioClip turnOffSound;
    [SerializeField] private AudioClip flickerSound;
    [SerializeField] private AudioClip batteryLowSound;
    [SerializeField] private AudioClip batteryDeadSound;
    
    [Header("UI References")]
    [SerializeField] private UnityEngine.UI.Image batteryIndicator; // Optional
    
    // Private variables
    private float currentBattery;
    private bool isOn = false;
    private bool isFlickering = false;
    private float baseIntensity;
    private float flickerTimer = 0f;
    private float lowBatteryTimer = 0f;
    private bool lowBatteryAlertPlayed = false;
    private bool criticalBatteryAlertPlayed = false;
    private PlayerController playerController; // Reference to check if player is running
    
    void Start()
    {
        // Auto-get components if not assigned
        if (flashlightLight == null)
            flashlightLight = GetComponent<Light>();
            
        if (audioSource == null)
            audioSource = GetComponent<AudioSource>();
            
        if (flashlightModel == null && transform.childCount > 0)
            flashlightModel = transform.GetChild(0).gameObject;
            
        // Initialize
        currentBattery = maxBatteryLife;
        baseIntensity = maxIntensity;
        
        // Start with flashlight off
        SetFlashlightState(false);
        
        // Get player controller reference
        playerController = FindObjectOfType<PlayerController>();
    }
    
    void Update()
    {
        // Toggle flashlight with F key (or any key you prefer)
        if (Input.GetKeyDown(KeyCode.F))
        {
            ToggleFlashlight();
        }
        
        // Reload battery with R (for testing, remove in final game)
        if (Input.GetKeyDown(KeyCode.R))
        {
            AddBattery(maxBatteryLife);
        }
        
        if (isOn)
        {
            // Drain battery
            DrainBattery(batteryDrainRate * Time.deltaTime);
            
            // Handle battery effects
            HandleBatteryLevel();
            
            // Handle flickering
            HandleFlicker();
            
            // Adjust intensity based on battery
            UpdateIntensity();
            
            // Check for battery death
            if (currentBattery <= 0)
            {
                currentBattery = 0;
                SetFlashlightState(false);
                PlaySound(batteryDeadSound);
            }
        }
        
        // Low battery periodic alert
        if (isOn && currentBattery <= batteryLowThreshold && currentBattery > 0)
        {
            lowBatteryTimer -= Time.deltaTime;
            if (lowBatteryTimer <= 0)
            {
                PlaySound(batteryLowSound);
                lowBatteryTimer = 5f; // Alert every 5 seconds
                
                // Visual indicator flicker
                if (batteryIndicator != null)
                    batteryIndicator.color = Color.red;
            }
        }
    }
    
    public void ToggleFlashlight()
    {
        SetFlashlightState(!isOn);
    }
    
    private void SetFlashlightState(bool state)
    {
        isOn = state;
        
        // Toggle light component
        if (flashlightLight != null)
            flashlightLight.enabled = isOn;
            
        // Toggle model visibility (optional - sometimes you want model always visible)
        if (flashlightModel != null)
        {
            // Uncomment if you want model to disappear when off
            // flashlightModel.SetActive(isOn);
        }
        
        // Play sound
        if (isOn)
            PlaySound(turnOnSound);
        else
            PlaySound(turnOffSound);
            
        // Reset flicker state
        isFlickering = false;
        flickerTimer = 0f;
        
        // Reset battery alerts
        lowBatteryAlertPlayed = false;
        criticalBatteryAlertPlayed = false;
    }
    
    private void DrainBattery(float amount)
    {
        // Drain faster if player is running (adds tension)
        if (playerController != null && playerController.IsRunning())
        {
            amount *= 1.5f; // 50% faster drain when running
        }
        
        currentBattery = Mathf.Max(0, currentBattery - amount);
    }
    
    public void AddBattery(float amount)
    {
        currentBattery = Mathf.Min(maxBatteryLife, currentBattery + amount);
        
        // Reset alerts
        lowBatteryAlertPlayed = false;
        criticalBatteryAlertPlayed = false;
        lowBatteryTimer = 0;
        
        // Reset UI color
        if (batteryIndicator != null)
            batteryIndicator.color = Color.white;
    }
    
    private void HandleBatteryLevel()
    {
        // Critical battery - heavy flicker
        if (currentBattery <= batteryCriticalThreshold)
        {
            isFlickering = true;
            if (!criticalBatteryAlertPlayed)
            {
                PlaySound(flickerSound);
                criticalBatteryAlertPlayed = true;
            }
        }
        // Low battery - occasional flicker
        else if (currentBattery <= batteryLowThreshold)
        {
            // Random flicker chance
            if (Random.value < 0.01f) // 1% chance per frame
            {
                isFlickering = true;
                if (!lowBatteryAlertPlayed)
                {
                    PlaySound(flickerSound);
                    lowBatteryAlertPlayed = true;
                }
            }
        }
        else
        {
            isFlickering = false;
        }
    }
    
    private void HandleFlicker()
    {
        if (!isFlickering && flashlightLight != null)
        {
            flashlightLight.intensity = baseIntensity;
            return;
        }
        
        // Create flicker effect
        flickerTimer += Time.deltaTime * flickerSpeed;
        float flickerValue = flickerCurve.Evaluate(Mathf.PingPong(flickerTimer, 1f));
        
        // Random flicker pattern
        float randomFlicker = Random.Range(0.7f, 1f);
        float targetIntensity = baseIntensity * (1 - flickerIntensity * flickerValue * randomFlicker);
        
        if (flashlightLight != null)
            flashlightLight.intensity = Mathf.Lerp(flashlightLight.intensity, targetIntensity, Time.deltaTime * 10f);
    }
    
    private void UpdateIntensity()
    {
        // Calculate intensity based on battery percentage
        float batteryPercent = currentBattery / maxBatteryLife;
        float intensityMultiplier = Mathf.Lerp(minIntensity / maxIntensity, 1f, batteryPercent);
        
        baseIntensity = maxIntensity * intensityMultiplier;
    }
    
    private void PlaySound(AudioClip clip)
    {
        if (clip != null && audioSource != null)
        {
            audioSource.clip = clip;
            audioSource.Play();
        }
    }
    
    // Public methods for UI and game systems
    
    public float GetBatteryPercentage()
    {
        return currentBattery / maxBatteryLife;
    }
    
    public float GetBatteryCurrent()
    {
        return currentBattery;
    }
    
    public float GetBatteryMax()
    {
        return maxBatteryLife;
    }
    
    public bool IsFlashlightOn()
    {
        return isOn;
    }
    
    public bool IsBatteryLow()
    {
        return currentBattery <= batteryLowThreshold;
    }
    
    public bool IsBatteryCritical()
    {
        return currentBattery <= batteryCriticalThreshold;
    }
}