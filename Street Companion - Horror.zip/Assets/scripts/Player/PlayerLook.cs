using UnityEngine;

public class PlayerLook : MonoBehaviour
{
    [Header("Mouse Settings")]
    [SerializeField] private float mouseSensitivity = 2f;
    [SerializeField] private float smoothing = 5f; // Плавность вращения
    [SerializeField] private bool invertY = false;
    [SerializeField] private Vector2 lookAngleLimits = new Vector2(-90f, 90f); // Ограничение по вертикали
    
    [Header("Camera Effects")]
    [SerializeField] private Camera playerCamera;
    [SerializeField] private float headBobbingAmount = 0.05f; // Качка головы при ходьбе
    [SerializeField] private float headBobbingSpeed = 10f;
    [SerializeField] private float crouchHeightOffset = -0.3f; // Смещение камеры при приседании
    
    [Header("Horror Effects")]
    [SerializeField] private float sanityShakeIntensity = 0.1f; // Дрожь при низком рассудке
    [SerializeField] private float sanityShakeSpeed = 5f;
    [SerializeField] private AnimationCurve fearCurve; // Кривая страха для эффектов
    [SerializeField] private float lookDelayWhenScared = 0.2f; // Задержка поворота при страхе
    
    [Header("Head Movement")]
    [SerializeField] private float maxHeadTilt = 10f; // Наклон головы при беге/поворотах
    [SerializeField] private float headTiltSpeed = 8f;
    [SerializeField] private Transform headBone; // Для анимации головы (опционально)
    
    [Header("Blur Effects")]
    [SerializeField] private Material blurMaterial;
    [SerializeField] private float blurIntensity = 0.5f;
    [SerializeField] private AnimationCurve blurCurve;
    
    [Header("References")]
    [SerializeField] private Transform playerBody; // Тело игрока (для горизонтального поворота)
    [SerializeField] private PlayerController playerController;
    
    // Private variables
    private float xRotation = 0f;
    private float yRotation = 0f;
    private float targetXRotation;
    private float targetYRotation;
    private Vector2 currentMouseDelta;
    private Vector2 smoothVelocity;
    
    // Head bobbing
    private float headBobTimer = 0f;
    private Vector3 originalCameraPosition;
    private float originalCameraHeight;
    
    // Horror effects
    private float sanityLevel = 1f; // 1 = норма, 0 = безумие
    private float fearTimer = 0f;
    private bool isScared = false;
    private float lookDelayTimer = 0f;
    
    // Tilt
    private float currentTilt = 0f;
    private float targetTilt = 0f;
    
    void Start()
    {
        // Lock cursor
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
        
        // Get references
        if (playerCamera == null)
            playerCamera = GetComponent<Camera>();
            
        if (playerBody == null)
            playerBody = transform.parent;
            
        if (playerController == null)
            playerController = GetComponentInParent<PlayerController>();
            
        // Store original camera position
        if (playerCamera != null)
        {
            originalCameraPosition = playerCamera.transform.localPosition;
            originalCameraHeight = originalCameraPosition.y;
        }
        
        // Initialize rotation
        if (playerBody != null)
        {
            yRotation = playerBody.eulerAngles.y;
            targetYRotation = yRotation;
        }
        
        xRotation = transform.localEulerAngles.x;
        if (xRotation > 180) xRotation -= 360;
        targetXRotation = xRotation;
    }
    
    void Update()
    {
        // Don't do anything if game is paused
        if (Time.timeScale == 0f) return;
        
        // Handle look delay when scared
        if (lookDelayTimer > 0f)
        {
            lookDelayTimer -= Time.deltaTime;
            return;
        }
        
        // Get mouse input
        float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity;
        float mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity * (invertY ? -1 : 1);
        
        // Apply fear effect - slower look when scared
        if (isScared)
        {
            mouseX *= (1f - sanityLevel * 0.5f);
            mouseY *= (1f - sanityLevel * 0.5f);
        }
        
        // Smooth mouse movement
        Vector2 targetDelta = new Vector2(mouseX, mouseY);
        currentMouseDelta = Vector2.SmoothDamp(currentMouseDelta, targetDelta, ref smoothVelocity, smoothing * Time.deltaTime);
        
        // Calculate target rotations
        targetYRotation += currentMouseDelta.x;
        targetXRotation -= currentMouseDelta.y;
        
        // Clamp vertical look
        targetXRotation = Mathf.Clamp(targetXRotation, lookAngleLimits.x, lookAngleLimits.y);
        
        // Smoothly interpolate rotations
        xRotation = Mathf.Lerp(xRotation, targetXRotation, Time.deltaTime * smoothing);
        yRotation = Mathf.Lerp(yRotation, targetYRotation, Time.deltaTime * smoothing);
        
        // Apply rotations
        if (playerBody != null)
            playerBody.rotation = Quaternion.Euler(0f, yRotation, 0f);
            
        transform.localRotation = Quaternion.Euler(xRotation, 0f, 0f);
        
        // Apply horror effects
        ApplyHorrorEffects();
        
        // Apply head bobbing
        ApplyHeadBobbing();
        
        // Apply head tilt
        ApplyHeadTilt();
        
        // Update camera effects
        UpdateCameraEffects();
    }
    
    private void ApplyHeadBobbing()
    {
        if (playerController == null || playerCamera == null) return;
        
        // Check if player is moving
        bool isMoving = Input.GetAxis("Horizontal") != 0 || Input.GetAxis("Vertical") != 0;
        bool isGrounded = playerController.IsGrounded(); // You need to add this method to PlayerController
        
        if (isMoving && isGrounded && !playerController.IsCrouching())
        {
            // Calculate head bobbing
            headBobTimer += Time.deltaTime * (playerController.IsRunning() ? headBobbingSpeed * 1.5f : headBobbingSpeed);
            
            float sinWave = Mathf.Sin(headBobTimer);
            float cosWave = Mathf.Cos(headBobTimer / 2f);
            
            // Vertical movement
            Vector3 newPosition = originalCameraPosition;
            newPosition.y += sinWave * headBobbingAmount * (playerController.IsRunning() ? 1.5f : 1f);
            
            // Horizontal movement (side to side)
            newPosition.x += cosWave * headBobbingAmount * 0.5f;
            
            playerCamera.transform.localPosition = Vector3.Lerp(playerCamera.transform.localPosition, newPosition, Time.deltaTime * 10f);
        }
        else
        {
            // Return to original position
            headBobTimer = 0f;
            playerCamera.transform.localPosition = Vector3.Lerp(playerCamera.transform.localPosition, originalCameraPosition, Time.deltaTime * 5f);
        }
    }
    
    private void ApplyHeadTilt()
    {
        // Calculate target tilt based on movement and running
        if (playerController != null && playerController.IsRunning())
        {
            // Tilt based on horizontal input
            float horizontalInput = Input.GetAxis("Horizontal");
            targetTilt = -horizontalInput * maxHeadTilt;
        }
        else
        {
            targetTilt = 0f;
        }
        
        // Smooth tilt
        currentTilt = Mathf.Lerp(currentTilt, targetTilt, Time.deltaTime * headTiltSpeed);
        
        // Apply tilt to camera
        if (playerCamera != null)
        {
            Vector3 currentEuler = playerCamera.transform.localEulerAngles;
            playerCamera.transform.localEulerAngles = new Vector3(currentEuler.x, currentEuler.y, currentTilt);
        }
        
        // Apply to head bone if exists
        if (headBone != null)
        {
            headBone.localEulerAngles = new Vector3(headBone.localEulerAngles.x, headBone.localEulerAngles.y, currentTilt * 0.5f);
        }
    }
    
    private void ApplyHorrorEffects()
    {
        if (playerCamera == null) return;
        
        // Sanity shake effect
        if (sanityLevel < 0.5f)
        {
            float shakeAmount = (0.5f - sanityLevel) * 2f * sanityShakeIntensity;
            float shakeX = Mathf.PerlinNoise(Time.time * sanityShakeSpeed, 0) * 2f - 1f;
            float shakeY = Mathf.PerlinNoise(0, Time.time * sanityShakeSpeed) * 2f - 1f;
            
            Vector3 shakeOffset = new Vector3(shakeX, shakeY, 0) * shakeAmount;
            playerCamera.transform.localPosition += shakeOffset;
        }
        
        // Fear response
        if (isScared)
        {
            fearTimer += Time.deltaTime;
            
            // Rapid breathing effect (camera movement)
            float breatheAmount = Mathf.Sin(fearTimer * 5f) * 0.02f;
            playerCamera.transform.localPosition += new Vector3(0, breatheAmount, 0);
        }
    }
    
    private void UpdateCameraEffects()
    {
        // Apply blur based on sanity/fear
        if (blurMaterial != null)
        {
            float blurAmount = 0f;
            
            if (sanityLevel < 0.3f)
            {
                blurAmount = blurCurve.Evaluate(1f - sanityLevel);
            }
            else if (isScared)
            {
                blurAmount = blurIntensity * 0.5f;
            }
            
            blurMaterial.SetFloat("_BlurAmount", blurAmount);
        }
    }
    
    // Public methods for other scripts
    
    public void SetSanity(float sanity)
    {
        sanityLevel = Mathf.Clamp01(sanity);
    }
    
    public void AddFear(float amount)
    {
        isScared = true;
        lookDelayTimer = lookDelayWhenScared;
        
        // Trigger fear effect
        StartCoroutine(FearRoutine());
    }
    
    private System.Collections.IEnumerator FearRoutine()
    {
        float fearDuration = 1f;
        float timer = 0f;
        float originalSensitivity = mouseSensitivity;
        
        // Reduce sensitivity temporarily
        mouseSensitivity *= 0.3f;
        
        while (timer < fearDuration)
        {
            float fearIntensity = fearCurve.Evaluate(timer / fearDuration);
            
            // Random camera jerks
            if (Random.value < 0.1f)
            {
                float jerkX = Random.Range(-5f, 5f);
                float jerkY = Random.Range(-3f, 3f);
                targetXRotation += jerkY;
                targetYRotation += jerkX;
            }
            
            timer += Time.deltaTime;
            yield return null;
        }
        
        mouseSensitivity = originalSensitivity;
        isScared = false;
    }
    
    public void LookAt(Transform target, float duration)
    {
        StartCoroutine(LookAtRoutine(target, duration));
    }
    
    private System.Collections.IEnumerator LookAtRoutine(Transform target, float duration)
    {
        if (target == null) yield break;
        
        // Calculate direction to target
        Vector3 directionToTarget = target.position - transform.position;
        Quaternion targetRotation = Quaternion.LookRotation(directionToTarget);
        
        // Extract angles
        Vector3 targetEuler = targetRotation.eulerAngles;
        
        // Set target rotations
        float startXRotation = xRotation;
        float startYRotation = yRotation;
        float targetX = targetEuler.x;
        float targetY = targetEuler.y;
        
        // Normalize angles
        if (targetX > 180) targetX -= 360;
        targetX = Mathf.Clamp(targetX, lookAngleLimits.x, lookAngleLimits.y);
        
        float timer = 0f;
        
        while (timer < duration)
        {
            float t = timer / duration;
            
            // Smooth interpolation
            targetXRotation = Mathf.Lerp(startXRotation, targetX, t);
            targetYRotation = Mathf.Lerp(startYRotation, targetY, t);
            
            timer += Time.deltaTime;
            yield return null;
        }
        
        targetXRotation = targetX;
        targetYRotation = targetY;
    }
    
    // Call this when player takes damage or sees something scary
    public void TriggerJumpscare(float intensity = 1f)
    {
        AddFear(intensity);
        
        // Camera shake
        if (playerCamera != null)
        {
            StartCoroutine(JumpscareShake(intensity));
        }
    }
    
    private System.Collections.IEnumerator JumpscareShake(float intensity)
    {
        float duration = 0.3f;
        float timer = 0f;
        Vector3 originalPos = playerCamera.transform.localPosition;
        
        while (timer < duration)
        {
            float shakeX = Random.Range(-intensity, intensity);
            float shakeY = Random.Range(-intensity, intensity);
            
            playerCamera.transform.localPosition = originalPos + new Vector3(shakeX, shakeY, 0);
            
            timer += Time.deltaTime;
            yield return null;
        }
        
        playerCamera.transform.localPosition = originalPos;
    }
    
    // Add these methods to PlayerController for reference
    // (You need to add these to your PlayerController.cs)
    public bool IsGrounded()
    {
        // Implement this in PlayerController
        return Physics.Raycast(transform.position, Vector3.down, 0.2f);
    }
}

// Extension method for PlayerController (add this to your PlayerController.cs)
/*
public bool IsGrounded()
{
    return characterController.isGrounded;
}
*/