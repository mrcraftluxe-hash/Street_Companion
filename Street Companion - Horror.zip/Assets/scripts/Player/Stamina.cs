using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Stamina : MonoBehaviour
{
    [Header("Stamina Settings")]
    [SerializeField] private float maxStamina = 100f;
    [SerializeField] private float currentStamina;
    [SerializeField] private float drainRate = 15f;
    [SerializeField] private float regenRate = 10f;
    [SerializeField] private float regenDelay = 1.5f;
    [SerializeField] private float exhaustedRegenDelay = 3f;
    
    [Header("Stamina Thresholds")]
    [SerializeField] private float lowStaminaThreshold = 30f;
    [SerializeField] private float criticalStaminaThreshold = 15f;
    [SerializeField] private float exhaustedThreshold = 5f;
    
    [Header("Movement Impact")]
    [SerializeField] private AnimationCurve speedCurve; // Кривая скорости от выносливости
    [SerializeField] private AnimationCurve accelerationCurve;
    [SerializeField] private float minSpeedMultiplier = 0.5f;
    [SerializeField] private float exhaustedSpeedMultiplier = 0.3f;
    
    [Header("Breathing Effects")]
    [SerializeField] private AudioSource breathingAudio;
    [SerializeField] private AudioClip breathingNormal;
    [SerializeField] private AudioClip breathingHeavy;
    [SerializeField] private AudioClip breathingExhausted;
    [SerializeField] private AnimationCurve breathingPitchCurve;
    [SerializeField] private AnimationCurve breathingVolumeCurve;
    [SerializeField] private float breathInterval = 3f;
    
    [Header("Visual Effects")]
    [SerializeField] private Image staminaBar;
    [SerializeField] private Image staminaBarFill;
    [SerializeField] private Color normalColor = Color.green;
    [SerializeField] private Color lowColor = Color.yellow;
    [SerializeField] private Color criticalColor = Color.red;
    [SerializeField] private Color exhaustedColor = Color.gray;
    
    [Header("Screen Effects")]
    [SerializeField] private Camera playerCamera;
    [SerializeField] private float exhaustedShakeIntensity = 0.1f;
    [SerializeField] private float exhaustedShakeSpeed = 5f;
    [SerializeField] private AnimationCurve vignetteIntensity;
    [SerializeField] private Material postProcessMaterial;
    
    [Header("Particle Effects")]
    [SerializeField] private ParticleSystem sweatParticles;
    [SerializeField] private float sweatEmissionRate = 10f;
    [SerializeField] private AnimationCurve sweatEmissionCurve;
    
    [Header("Recovery Items")]
    [SerializeField] private float staminaRestoreAmount = 30f;
    [SerializeField] private AudioClip staminaRestoreSound;
    
    [Header("Fear Impact")]
    [SerializeField] private float fearDrainMultiplier = 1.5f; // Страх ускоряет расход
    [SerializeField] private float fearRegenPenalty = 0.5f; // Замедление восстановления
    
    // Private variables
    private float regenTimer;
    private float breathTimer;
    private float originalFOV;
    private Vector3 originalCameraPosition;
    private bool isExhausted;
    private bool isRecovering;
    private float currentDrainRate;
    private float currentRegenRate;
    private PlayerMovement playerMovement;
    private PlayerSanity playerSanity;
    private float exhaustionTime;
    private float lastStaminaValue;
    
    // Events
    public System.Action<float> OnStaminaChanged;
    public System.Action OnStaminaExhausted;
    public System.Action OnStaminaRecovered;
    public System.Action<StaminaState> OnStaminaStateChanged;
    
    public enum StaminaState
    {
        Normal,
        Low,
        Critical,
        Exhausted
    }
    
    private StaminaState currentState = StaminaState.Normal;
    
    void Start()
    {
        // Initialize
        currentStamina = maxStamina;
        lastStaminaValue = maxStamina;
        
        // Get components
        if (playerMovement == null)
            playerMovement = GetComponent<PlayerMovement>();
            
        if (playerSanity == null)
            playerSanity = GetComponent<PlayerSanity>();
            
        if (playerCamera == null)
            playerCamera = Camera.main;
            
        if (playerCamera != null)
        {
            originalFOV = playerCamera.fieldOfView;
            originalCameraPosition = playerCamera.transform.localPosition;
        }
        
        // Setup UI
        UpdateStaminaBar();
        
        // Start breathing
        breathTimer = breathInterval;
    }
    
    void Update()
    {
        // Update drain rates based on state
        UpdateDrainRates();
        
        // Handle stamina consumption
        HandleStaminaDrain();
        
        // Handle stamina regeneration
        HandleStaminaRegen();
        
        // Clamp stamina
        currentStamina = Mathf.Clamp(currentStamina, 0, maxStamina);
        
        // Check for state changes
        UpdateStaminaState();
        
        // Apply effects
        ApplyBreathingEffects();
        ApplyScreenEffects();
        ApplyParticleEffects();
        
        // Update UI
        UpdateStaminaBar();
        
        // Check for exhaustion
        CheckExhaustion();
        
        // Invoke event if stamina changed significantly
        if (Mathf.Abs(currentStamina - lastStaminaValue) > 0.5f)
        {
            OnStaminaChanged?.Invoke(currentStamina / maxStamina);
            lastStaminaValue = currentStamina;
        }
    }
    
    void UpdateDrainRates()
    {
        // Base drain rate
        currentDrainRate = drainRate;
        currentRegenRate = regenRate;
        
        // Apply fear penalty
        if (playerSanity != null && playerSanity.GetSanityNormalized() < 0.3f)
        {
            currentDrainRate *= fearDrainMultiplier;
            currentRegenRate *= fearRegenPenalty;
        }
        
        // Apply exhaustion penalty
        if (isExhausted)
        {
            currentRegenRate *= 0.5f;
        }
    }
    
    void HandleStaminaDrain()
    {
        // Check if player is running
        if (playerMovement != null && playerMovement.IsRunning && playerMovement.IsMoving)
        {
            // Drain stamina
            currentStamina -= currentDrainRate * Time.deltaTime;
            regenTimer = 0f;
            
            // Reset recovery flag
            isRecovering = false;
        }
    }
    
    void HandleStaminaRegen()
    {
        // Check if we should regen
        if (!playerMovement.IsRunning || !playerMovement.IsMoving)
        {
            regenTimer += Time.deltaTime;
            
            float requiredDelay = isExhausted ? exhaustedRegenDelay : regenDelay;
            
            if (regenTimer >= requiredDelay)
            {
                isRecovering = true;
                currentStamina += currentRegenRate * Time.deltaTime;
            }
        }
    }
    
    void UpdateStaminaState()
    {
        StaminaState newState;
        
        if (isExhausted || currentStamina <= exhaustedThreshold)
            newState = StaminaState.Exhausted;
        else if (currentStamina <= criticalStaminaThreshold)
            newState = StaminaState.Critical;
        else if (currentStamina <= lowStaminaThreshold)
            newState = StaminaState.Low;
        else
            newState = StaminaState.Normal;
            
        if (newState != currentState)
        {
            currentState = newState;
            OnStaminaStateChanged?.Invoke(currentState);
        }
    }
    
    void CheckExhaustion()
    {
        if (currentStamina <= 0 && !isExhausted)
        {
            EnterExhaustion();
        }
        else if (isExhausted && currentStamina >= maxStamina * 0.3f)
        {
            ExitExhaustion();
        }
    }
    
    void EnterExhaustion()
    {
        isExhausted = true;
        exhaustionTime = Time.time;
        
        // Trigger event
        OnStaminaExhausted?.Invoke();
        
        // Visual feedback
        if (sweatParticles != null)
            sweatParticles.Play();
            
        // Force player to stop running
        if (playerMovement != null)
            playerMovement.ForceStopRunning(); // Добавьте этот метод в PlayerMovement
    }
    
    void ExitExhaustion()
    {
        isExhausted = false;
        
        // Trigger event
        OnStaminaRecovered?.Invoke();
        
        // Stop particles
        if (sweatParticles != null)
            sweatParticles.Stop();
    }
    
    void ApplyBreathingEffects()
    {
        if (breathingAudio == null) return;
        
        float staminaPercent = currentStamina / maxStamina;
        
        // Select breathing clip based on stamina
        if (isExhausted || staminaPercent < criticalStaminaThreshold)
        {
            if (breathingAudio.clip != breathingExhausted)
            {
                breathingAudio.clip = breathingExhausted;
                breathingAudio.loop = true;
                breathingAudio.Play();
            }
        }
        else if (staminaPercent < lowStaminaThreshold)
        {
            if (breathingAudio.clip != breathingHeavy)
            {
                breathingAudio.clip = breathingHeavy;
                breathingAudio.loop = true;
                breathingAudio.Play();
            }
        }
        else
        {
            if (breathingAudio.clip != breathingNormal)
            {
                breathingAudio.clip = breathingNormal;
                breathingAudio.loop = true;
                breathingAudio.Play();
            }
        }
        
        // Adjust pitch and volume
        breathingAudio.pitch = breathingPitchCurve.Evaluate(1f - staminaPercent);
        breathingAudio.volume = breathingVolumeCurve.Evaluate(1f - staminaPercent);
    }
    
    void ApplyScreenEffects()
    {
        if (postProcessMaterial == null || playerCamera == null) return;
        
        float staminaPercent = currentStamina / maxStamina;
        
        // Apply vignette based on exhaustion
        float vignette = vignetteIntensity.Evaluate(1f - staminaPercent);
        postProcessMaterial.SetFloat("_VignetteIntensity", vignette);
        
        // Camera shake when exhausted
        if (isExhausted)
        {
            float shakeX = Mathf.PerlinNoise(Time.time * exhaustedShakeSpeed, 0) * 2f - 1f;
            float shakeY = Mathf.PerlinNoise(0, Time.time * exhaustedShakeSpeed) * 2f - 1f;
            
            Vector3 shakeOffset = new Vector3(shakeX, shakeY, 0) * exhaustedShakeIntensity;
            playerCamera.transform.localPosition = originalCameraPosition + shakeOffset;
        }
        else
        {
            // Return to original position
            playerCamera.transform.localPosition = Vector3.Lerp(
                playerCamera.transform.localPosition, 
                originalCameraPosition, 
                Time.deltaTime * 5f
            );
        }
        
        // FOV effect when running
        if (playerMovement != null && playerMovement.IsRunning)
        {
            float targetFOV = originalFOV + 5f;
            playerCamera.fieldOfView = Mathf.Lerp(playerCamera.fieldOfView, targetFOV, Time.deltaTime * 5f);
        }
        else
        {
            playerCamera.fieldOfView = Mathf.Lerp(playerCamera.fieldOfView, originalFOV, Time.deltaTime * 5f);
        }
    }
    
    void ApplyParticleEffects()
    {
        if (sweatParticles == null) return;
        
        float staminaPercent = currentStamina / maxStamina;
        float emissionRate = sweatEmissionCurve.Evaluate(1f - staminaPercent) * sweatEmissionRate;
        
        var emission = sweatParticles.emission;
        emission.rateOverTime = emissionRate;
    }
    
    void UpdateStaminaBar()
    {
        if (staminaBar != null)
        {
            staminaBar.fillAmount = currentStamina / maxStamina;
        }
        
        if (staminaBarFill != null)
        {
            // Change color based on state
            switch (currentState)
            {
                case StaminaState.Normal:
                    staminaBarFill.color = normalColor;
                    break;
                case StaminaState.Low:
                    staminaBarFill.color = lowColor;
                    break;
                case StaminaState.Critical:
                    staminaBarFill.color = criticalColor;
                    break;
                case StaminaState.Exhausted:
                    staminaBarFill.color = exhaustedColor;
                    break;
            }
            
            // Pulse effect when critical
            if (currentState == StaminaState.Critical || currentState == StaminaState.Exhausted)
            {
                float pulse = Mathf.Sin(Time.time * 5f) * 0.2f + 0.8f;
                staminaBarFill.transform.localScale = Vector3.one * pulse;
            }
            else
            {
                staminaBarFill.transform.localScale = Vector3.one;
            }
        }
    }
    
    // Public methods for other scripts
    
    public void DrainStamina(float amount)
    {
        currentStamina = Mathf.Max(0, currentStamina - amount);
        regenTimer = 0f;
    }
    
    public void RestoreStamina(float amount)
    {
        currentStamina = Mathf.Min(maxStamina, currentStamina + amount);
        
        // Play restore sound
        if (staminaRestoreSound != null && breathingAudio != null)
        {
            breathingAudio.PlayOneShot(staminaRestoreSound);
        }
    }
    
    public void RestoreStaminaFromItem()
    {
        RestoreStamina(staminaRestoreAmount);
    }
    
    public float GetStaminaNormalized()
    {
        return currentStamina / maxStamina;
    }
    
    public float GetCurrentStamina()
    {
        return currentStamina;
    }
    
    public bool IsExhausted()
    {
        return isExhausted;
    }
    
    public bool CanRun()
    {
        return !isExhausted && currentStamina > 0;
    }
    
    public float GetSpeedMultiplier()
    {
        if (isExhausted)
            return exhaustedSpeedMultiplier;
            
        float staminaPercent = currentStamina / maxStamina;
        return Mathf.Max(speedCurve.Evaluate(staminaPercent), minSpeedMultiplier);
    }
    
    public float GetAccelerationMultiplier()
    {
        float staminaPercent = currentStamina / maxStamina;
        return accelerationCurve.Evaluate(staminaPercent);
    }
    
    public StaminaState GetStaminaState()
    {
        return currentState;
    }
    
    public string GetStaminaStateText()
    {
        switch (currentState)
        {
            case StaminaState.Normal: return "Норма";
            case StaminaState.Low: return "Низкая";
            case StaminaState.Critical: return "Критическая";
            case StaminaState.Exhausted: return "Истощение";
            default: return "";
        }
    }
    
    // Call this when player gets scared
    public void OnFearTriggered(float intensity)
    {
        // Instant stamina drain from fear
        DrainStamina(intensity * 10f);
        
        // Visual feedback
        StartCoroutine(StaminaFlashRoutine());
    }
    
    IEnumerator StaminaFlashRoutine()
    {
        if (staminaBarFill == null) yield break;
        
        Color originalColor = staminaBarFill.color;
        staminaBarFill.color = Color.white;
        
        yield return new WaitForSeconds(0.1f);
        
        staminaBarFill.color = originalColor;
    }
    
    // For energy drinks or items
    public void ApplyStaminaBoost(float boostMultiplier, float duration)
    {
        StartCoroutine(StaminaBoostRoutine(boostMultiplier, duration));
    }
    
    IEnumerator StaminaBoostRoutine(float multiplier, float duration)
    {
        float originalDrainRate = drainRate;
        float originalRegenRate = regenRate;
        
        drainRate *= multiplier;
        regenRate *= multiplier;
        
        yield return new WaitForSeconds(duration);
        
        drainRate = originalDrainRate;
        regenRate = originalRegenRate;
    }
}

// Extension for PlayerMovement - добавьте этот метод в PlayerMovement.cs
/*
public void ForceStopRunning()
{
    isRunning = false;
}
*/