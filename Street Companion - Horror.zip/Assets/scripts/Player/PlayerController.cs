using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [Header("Movement Settings")]
    [SerializeField] private float walkSpeed = 4f;
    [SerializeField] private float runSpeed = 7f;
    [SerializeField] private float crouchSpeed = 2f;
    [SerializeField] private float jumpForce = 5f;
    [SerializeField] private float groundCheckDistance = 0.2f;
    
    [Header("Stamina Settings")]
    [SerializeField] private float maxStamina = 100f;
    [SerializeField] private float staminaDrainRate = 15f;
    [SerializeField] private float staminaRegenRate = 10f;
    [SerializeField] private float staminaRegenDelay = 1.5f;
    
    [Header("Camera Settings")]
    [SerializeField] private Transform playerCamera;
    [SerializeField] private float mouseSensitivity = 2f;
    [SerializeField] private float maxLookAngle = 80f;
    [SerializeField] private float crouchHeight = 1f;
    [SerializeField] private float standingHeight = 2f;
    
    [Header("Footsteps")]
    [SerializeField] private AudioSource footstepAudio;
    [SerializeField] private float walkStepInterval = 0.5f;
    [SerializeField] private float runStepInterval = 0.3f;
    [SerializeField] private AudioClip[] footstepSounds;
    
    // Private variables
    private CharacterController characterController;
    private float currentSpeed;
    private float currentStamina;
    private float staminaRegenTimer;
    private float verticalRotation = 0f;
    private float stepTimer = 0f;
    private bool isGrounded;
    private bool isCrouching = false;
    private bool isRunning = false;
    private Vector3 moveDirection;
    private Vector3 velocity;
    
    void Start()
    {
        characterController = GetComponent<CharacterController>();
        currentStamina = maxStamina;
        
        // Lock and hide cursor
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }
    
    void Update()
    {
        HandleMovement();
        HandleMouseLook();
        HandleStamina();
        HandleFootsteps();
        HandleCrouch();
    }
    
    void HandleMovement()
    {
        isGrounded = characterController.isGrounded;
        
        if (isGrounded && velocity.y < 0)
        {
            velocity.y = -2f; // Small downward force to keep grounded
        }
        
        // Get input
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");
        
        // Calculate movement direction relative to player
        Vector3 move = transform.right * horizontal + transform.forward * vertical;
        
        // Determine current speed based on state
        if (Input.GetKey(KeyCode.LeftShift) && currentStamina > 0 && !isCrouching)
        {
            isRunning = true;
            currentSpeed = runSpeed;
            DrainStamina(staminaDrainRate * Time.deltaTime);
        }
        else if (isCrouching)
        {
            isRunning = false;
            currentSpeed = crouchSpeed;
        }
        else
        {
            isRunning = false;
            currentSpeed = walkSpeed;
        }
        
        // Apply movement
        characterController.Move(move * currentSpeed * Time.deltaTime);
        
        // Jump
        if (Input.GetButtonDown("Jump") && isGrounded && !isCrouching)
        {
            velocity.y = Mathf.Sqrt(jumpForce * -2f * Physics.gravity.y);
        }
        
        // Apply gravity
        velocity.y += Physics.gravity.y * Time.deltaTime;
        characterController.Move(velocity * Time.deltaTime);
    }
    
    void HandleMouseLook()
    {
        float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity;
        float mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity;
        
        // Horizontal rotation (player body)
        transform.Rotate(Vector3.up * mouseX);
        
        // Vertical rotation (camera only)
        verticalRotation -= mouseY;
        verticalRotation = Mathf.Clamp(verticalRotation, -maxLookAngle, maxLookAngle);
        playerCamera.localRotation = Quaternion.Euler(verticalRotation, 0f, 0f);
    }
    
    void HandleStamina()
    {
        if (isRunning && characterController.velocity.magnitude > 0.1f)
        {
            staminaRegenTimer = 0f;
        }
        else
        {
            staminaRegenTimer += Time.deltaTime;
            
            if (staminaRegenTimer >= staminaRegenDelay)
            {
                RegenerateStamina(staminaRegenRate * Time.deltaTime);
            }
        }
        
        // Clamp stamina
        currentStamina = Mathf.Clamp(currentStamina, 0, maxStamina);
    }
    
    void DrainStamina(float amount)
    {
        currentStamina -= amount;
        if (currentStamina < 0) currentStamina = 0;
    }
    
    void RegenerateStamina(float amount)
    {
        currentStamina += amount;
        if (currentStamina > maxStamina) currentStamina = maxStamina;
    }
    
    void HandleFootsteps()
    {
        if (!isGrounded || characterController.velocity.magnitude < 0.1f)
        {
            stepTimer = 0f;
            return;
        }
        
        float currentInterval = isRunning ? runStepInterval : walkStepInterval;
        
        stepTimer -= Time.deltaTime;
        
        if (stepTimer <= 0f)
        {
            PlayFootstepSound();
            stepTimer = currentInterval;
        }
    }
    
    void PlayFootstepSound()
    {
        if (footstepSounds != null && footstepSounds.Length > 0 && footstepAudio != null)
        {
            int randomIndex = Random.Range(0, footstepSounds.Length);
            footstepAudio.clip = footstepSounds[randomIndex];
            footstepAudio.pitch = Random.Range(0.9f, 1.1f); // Slight pitch variation
            footstepAudio.Play();
        }
    }
    
    void HandleCrouch()
    {
        if (Input.GetKeyDown(KeyCode.C) || Input.GetKeyDown(KeyCode.LeftControl))
        {
            isCrouching = !isCrouching;
            
            // Adjust controller height and camera position
            float targetHeight = isCrouching ? crouchHeight : standingHeight;
            Vector3 newCameraPosition = playerCamera.localPosition;
            newCameraPosition.y = targetHeight - 0.3f; // Adjust camera position relative to crouch
            
            playerCamera.localPosition = newCameraPosition;
            
            // Resize character controller
            characterController.height = targetHeight;
            characterController.center = new Vector3(0, targetHeight / 2f, 0);
        }
    }
    
    // Public method to get current stamina percentage (for UI)
    public float GetStaminaPercentage()
    {
        return currentStamina / maxStamina;
    }
    
    // Public method to check if player is running
    public bool IsRunning()
    {
        return isRunning;
    }
    
    // Public method to check if player is crouching
    public bool IsCrouching()
    {
        return isCrouching;
    }
// Добавь эти методы в PlayerController.cs
   public bool IsGrounded()
{
    return characterController.isGrounded;
}