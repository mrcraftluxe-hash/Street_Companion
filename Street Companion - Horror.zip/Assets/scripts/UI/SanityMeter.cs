using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using TMPro; // Для TextMeshPro (опционально)

public class SanityMeter : MonoBehaviour
{
    [Header("UI References")]
    [SerializeField] private Image sanityFill; // Основная шкала
    [SerializeField] private Image sanityBackground; // Фон шкалы
    [SerializeField] private Image sanityGlow; // Свечение вокруг шкалы
    [SerializeField] private TextMeshProUGUI sanityText; // Текст процентов
    [SerializeField] private TextMeshProUGUI stateText; // Текст состояния (Норма, Безумие...)
    
    [Header("Colors")]
    [SerializeField] private Color normalColor = new Color(0.2f, 0.8f, 0.2f); // Зеленый
    [SerializeField] private Color mildColor = new Color(0.8f, 0.8f, 0.2f); // Желтый
    [SerializeField] private Color moderateColor = new Color(0.8f, 0.5f, 0.2f); // Оранжевый
    [SerializeField] private Color severeColor = new Color(0.8f, 0.2f, 0.2f); // Красный
    [SerializeField] private Color criticalColor = new Color(0.5f, 0f, 0f); // Темно-красный
    
    [Header("Animation Settings")]
    [SerializeField] private float fillSpeed = 5f; // Скорость заполнения шкалы
    [SerializeField] private float pulseSpeed = 2f; // Скорость пульсации
    [SerializeField] private float pulseAmount = 0.1f; // Сила пульсации
    [SerializeField] private AnimationCurve pulseCurve; // Кривая пульсации
    
    [Header("Glow Effects")]
    [SerializeField] private float glowIntensity = 1f;
    [SerializeField] private AnimationCurve glowCurve;
    [SerializeField] private Color glowColor = Color.white;
    
    [Header("Warnings")]
    [SerializeField] private GameObject warningIcon; // Иконка предупреждения
    [SerializeField] private Image warningFlash; // Вспышка предупреждения
    [SerializeField] private float flashSpeed = 5f;
    [SerializeField] private float flashIntensity = 0.5f;
    
    [Header("Threshold Markers")]
    [SerializeField] private RectTransform markerParent; // Родитель для маркеров
    [SerializeField] private GameObject markerPrefab; // Префаб маркера
    [SerializeField] private float[] thresholds = { 70f, 40f, 20f, 10f }; // Пороги для маркеров
    
    [Header("Effects")]
    [SerializeField] private ParticleSystem sanityParticles; // Частицы на шкале
    [SerializeField] private AudioSource audioSource;
    [SerializeField] private AudioClip lowSanitySound;
    [SerializeField] private AudioClip criticalSound;
    [SerializeField] private AudioClip sanityRecoverSound;
    
    [Header("Screen Effects")]
    [SerializeField] private Image screenOverlay; // Оверлей на весь экран
    [SerializeField] private Color overlayNormal = Color.clear;
    [SerializeField] private Color overlayLow = new Color(0.5f, 0f, 0f, 0.2f);
    [SerializeField] private Color overlayCritical = new Color(1f, 0f, 0f, 0.4f);
    
    [Header("References")]
    [SerializeField] private PlayerSanity playerSanity;
    [SerializeField] private RectTransform meterRect; // RectTransform шкалы
    
    // Private variables
    private float targetFillAmount = 1f;
    private float currentFillAmount = 1f;
    private float pulseTimer = 0f;
    private float warningTimer = 0f;
    private bool wasLowSanity = false;
    private bool wasCritical = false;
    private PlayerSanity.SanityState currentState;
    private Coroutine warningRoutine;
    
    void Start()
    {
        // Get components if not assigned
        if (playerSanity == null)
            playerSanity = FindObjectOfType<PlayerSanity>();
            
        if (audioSource == null)
            audioSource = GetComponent<AudioSource>();
            
        if (meterRect == null && sanityFill != null)
            meterRect = sanityFill.rectTransform.parent as RectTransform;
            
        // Initialize
        if (sanityFill != null)
        {
            currentFillAmount = playerSanity != null ? playerSanity.GetSanityNormalized() : 1f;
            sanityFill.fillAmount = currentFillAmount;
        }
        
        // Create threshold markers
        CreateThresholdMarkers();
        
        // Subscribe to sanity events
        if (playerSanity != null)
        {
            playerSanity.OnSanityChanged += UpdateSanity;
            playerSanity.OnSanityStateChanged += OnSanityStateChanged;
        }
    }
    
    void Update()
    {
        if (playerSanity == null || sanityFill == null) return;
        
        // Smooth fill animation
        currentFillAmount = Mathf.Lerp(currentFillAmount, targetFillAmount, Time.deltaTime * fillSpeed);
        sanityFill.fillAmount = currentFillAmount;
        
        // Update pulse timer
        pulseTimer += Time.deltaTime * pulseSpeed;
        
        // Apply visual effects based on sanity
        UpdateColor();
        UpdatePulse();
        UpdateGlow();
        UpdateWarnings();
        UpdateText();
        UpdateScreenOverlay();
        UpdateParticleEffects();
    }
    
    void UpdateSanity(float sanityPercent)
    {
        targetFillAmount = sanityPercent;
    }
    
    void OnSanityStateChanged(PlayerSanity.SanityState state)
    {
        currentState = state;
        
        // Update state text
        if (stateText != null)
        {
            stateText.text = GetStateName(state);
        }
        
        // Play sounds based on state
        if (state == PlayerSanity.SanityState.Critical && !wasCritical)
        {
            PlayCriticalSound();
            wasCritical = true;
            wasLowSanity = true;
        }
        else if (state == PlayerSanity.SanityState.Severe && !wasLowSanity)
        {
            PlayLowSanitySound();
            wasLowSanity = true;
        }
        else if (state == PlayerSanity.SanityState.Normal)
        {
            if (wasLowSanity || wasCritical)
            {
                PlayRecoverSound();
            }
            wasLowSanity = false;
            wasCritical = false;
        }
    }
    
    void UpdateColor()
    {
        if (sanityFill == null) return;
        
        // Change color based on sanity level
        float sanity = targetFillAmount;
        
        if (sanity <= 0.1f)
            sanityFill.color = criticalColor;
        else if (sanity <= 0.2f)
            sanityFill.color = severeColor;
        else if (sanity <= 0.4f)
            sanityFill.color = moderateColor;
        else if (sanity <= 0.7f)
            sanityFill.color = mildColor;
        else
            sanityFill.color = normalColor;
            
        // Background color follows with less intensity
        if (sanityBackground != null)
        {
            Color bgColor = sanityFill.color;
            bgColor.a = 0.3f;
            sanityBackground.color = bgColor;
        }
    }
    
    void UpdatePulse()
    {
        if (sanityFill == null) return;
        
        // Pulse effect at low sanity
        float sanity = targetFillAmount;
        float pulse = 1f;
        
        if (sanity <= 0.3f)
        {
            float pulseValue = pulseCurve.Evaluate(Mathf.PingPong(pulseTimer, 1f));
            pulse = 1f + pulseValue * pulseAmount * (1f - sanity * 2f);
            
            // Apply pulse to scale
            sanityFill.rectTransform.localScale = Vector3.one * pulse;
            
            // Pulse opacity
            Color color = sanityFill.color;
            color.a = 0.8f + pulseValue * 0.2f;
            sanityFill.color = color;
        }
        else
        {
            // Return to normal scale
            sanityFill.rectTransform.localScale = Vector3.Lerp(
                sanityFill.rectTransform.localScale, 
                Vector3.one, 
                Time.deltaTime * 5f
            );
        }
    }
    
    void UpdateGlow()
    {
        if (sanityGlow == null) return;
        
        float sanity = targetFillAmount;
        float glowIntensity = 0f;
        
        if (sanity <= 0.3f)
        {
            float glowValue = glowCurve.Evaluate(Mathf.PingPong(pulseTimer, 1f));
            glowIntensity = this.glowIntensity * (1f - sanity) * glowValue;
        }
        
        // Apply glow
        Color glowColor = this.glowColor;
        glowColor.a = glowIntensity;
        sanityGlow.color = glowColor;
        
        // Rotate glow
        if (sanityGlow.transform != null)
        {
            sanityGlow.transform.Rotate(0, 0, Time.deltaTime * 30f);
        }
    }
    
    void UpdateWarnings()
    {
        if (warningIcon == null) return;
        
        float sanity = targetFillAmount;
        
        // Show warning icon at low sanity
        if (sanity <= 0.3f)
        {
            if (!warningIcon.activeSelf)
                warningIcon.SetActive(true);
                
            // Flash warning
            if (warningFlash != null)
            {
                float flash = (Mathf.Sin(Time.time * flashSpeed) + 1f) * 0.5f * flashIntensity;
                warningFlash.color = new Color(1f, 0f, 0f, flash);
            }
        }
        else
        {
            if (warningIcon.activeSelf)
                warningIcon.SetActive(false);
                
            if (warningFlash != null)
            {
                warningFlash.color = Color.clear;
            }
        }
    }
    
    void UpdateText()
    {
        if (sanityText != null)
        {
            int sanityPercent = Mathf.RoundToInt(targetFillAmount * 100f);
            sanityText.text = $"{sanityPercent}%";
            
            // Change text color based on sanity
            if (targetFillAmount <= 0.2f)
                sanityText.color = criticalColor;
            else if (targetFillAmount <= 0.4f)
                sanityText.color = severeColor;
            else
                sanityText.color = Color.white;
        }
    }
    
    void UpdateScreenOverlay()
    {
        if (screenOverlay == null) return;
        
        float sanity = targetFillAmount;
        
        if (sanity <= 0.2f)
        {
            // Critical - strong red overlay
            screenOverlay.color = Color.Lerp(
                screenOverlay.color,
                overlayCritical,
                Time.deltaTime * 3f
            );
        }
        else if (sanity <= 0.4f)
        {
            // Low - subtle red overlay
            screenOverlay.color = Color.Lerp(
                screenOverlay.color,
                overlayLow,
                Time.deltaTime * 2f
            );
        }
        else
        {
            // Normal - clear
            screenOverlay.color = Color.Lerp(
                screenOverlay.color,
                overlayNormal,
                Time.deltaTime * 5f
            );
        }
    }
    
    void UpdateParticleEffects()
    {
        if (sanityParticles == null) return;
        
        float sanity = targetFillAmount;
        
        // Enable particles at low sanity
        if (sanity <= 0.3f)
        {
            if (!sanityParticles.isPlaying)
                sanityParticles.Play();
                
            // Adjust emission rate
            var emission = sanityParticles.emission;
            emission.rateOverTime = 10f * (1f - sanity);
        }
        else
        {
            if (sanityParticles.isPlaying)
                sanityParticles.Stop();
        }
    }
    
    void CreateThresholdMarkers()
    {
        if (markerParent == null || markerPrefab == null || meterRect == null) return;
        
        foreach (float threshold in thresholds)
        {
            GameObject marker = Instantiate(markerPrefab, markerParent);
            
            // Position marker based on threshold percentage
            float normalizedThreshold = threshold / 100f;
            RectTransform markerRect = marker.GetComponent<RectTransform>();
            
            // Calculate position (assuming horizontal fill from left to right)
            float meterWidth = meterRect.rect.width;
            float xPos = normalizedThreshold * meterWidth - meterWidth * 0.5f;
            
            markerRect.anchoredPosition = new Vector2(xPos, 0);
            
            // Set marker color based on threshold
            Image markerImage = marker.GetComponent<Image>();
            if (markerImage != null)
            {
                if (threshold <= 10f)
                    markerImage.color = criticalColor;
                else if (threshold <= 20f)
                    markerImage.color = severeColor;
                else if (threshold <= 40f)
                    markerImage.color = moderateColor;
                else
                    markerImage.color = mildColor;
            }
            
            // Add text if needed
            TextMeshProUGUI markerText = marker.GetComponentInChildren<TextMeshProUGUI>();
            if (markerText != null)
            {
                markerText.text = $"{threshold}%";
            }
        }
    }
    
    string GetStateName(PlayerSanity.SanityState state)
    {
        switch (state)
        {
            case PlayerSanity.SanityState.Normal: return "НОРМА";
            case PlayerSanity.SanityState.Mild: return "БЕСПОКОЙСТВО";
            case PlayerSanity.SanityState.Moderate: return "СМЯТЕНИЕ";
            case PlayerSanity.SanityState.Severe: return "БЕЗУМИЕ";
            case PlayerSanity.SanityState.Critical: return "КРИТИЧЕСКОЕ";
            default: return "";
        }
    }
    
    void PlayLowSanitySound()
    {
        if (audioSource != null && lowSanitySound != null)
        {
            audioSource.PlayOneShot(lowSanitySound);
        }
    }
    
    void PlayCriticalSound()
    {
        if (audioSource != null && criticalSound != null)
        {
            audioSource.PlayOneShot(criticalSound);
        }
        
        // Start warning routine
        if (warningRoutine != null)
            StopCoroutine(warningRoutine);
        warningRoutine = StartCoroutine(CriticalWarningRoutine());
    }
    
    void PlayRecoverSound()
    {
        if (audioSource != null && sanityRecoverSound != null)
        {
            audioSource.PlayOneShot(sanityRecoverSound);
        }
    }
    
    IEnumerator CriticalWarningRoutine()
    {
        // Screen shake or flash effect
        float duration = 2f;
        float timer = 0f;
        
        while (timer < duration)
        {
            if (screenOverlay != null)
            {
                float intensity = (Mathf.Sin(Time.time * 20f) + 1f) * 0.5f;
                screenOverlay.color = new Color(1f, 0f, 0f, intensity * 0.3f);
            }
            
            timer += Time.deltaTime;
            yield return null;
        }
    }
    
    // Public method for external triggers (like jumpscares)
    public void FlashSanityMeter()
    {
        StartCoroutine(FlashRoutine());
    }
    
    IEnumerator FlashRoutine()
    {
        if (sanityFill == null) yield break;
        
        Color originalColor = sanityFill.color;
        Vector3 originalScale = sanityFill.rectTransform.localScale;
        
        // Flash white
        sanityFill.color = Color.white;
        sanityFill.rectTransform.localScale = originalScale * 1.2f;
        
        yield return new WaitForSeconds(0.1f);
        
        // Return to normal
        sanityFill.color = originalColor;
        sanityFill.rectTransform.localScale = originalScale;
    }
    
    // Call this when player takes sanity damage
    public void OnSanityDamage(float amount)
    {
        FlashSanityMeter();
        
        // Shake the meter
        if (meterRect != null)
        {
            StartCoroutine(ShakeRoutine());
        }
    }
    
    IEnumerator ShakeRoutine()
    {
        Vector3 originalPosition = meterRect.anchoredPosition;
        float duration = 0.2f;
        float timer = 0f;
        
        while (timer < duration)
        {
            float shakeX = Random.Range(-5f, 5f);
            float shakeY = Random.Range(-5f, 5f);
            
            meterRect.anchoredPosition = originalPosition + new Vector2(shakeX, shakeY);
            
            timer += Time.deltaTime;
            yield return null;
        }
        
        meterRect.anchoredPosition = originalPosition;
    }
    
    void OnDestroy()
    {
        // Unsubscribe from events
        if (playerSanity != null)
        {
            playerSanity.OnSanityChanged -= UpdateSanity;
            playerSanity.OnSanityStateChanged -= OnSanityStateChanged;
        }
    }
}